import * as i0 from "@angular/core";
import { InjectionToken, NgZone } from "@angular/core";
import { BreakPoint, LayoutConfigOptions, StylesheetMap, ɵMatchMedia } from "@angular/flex-layout/core";
export declare class FlexLayoutServerModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<FlexLayoutServerModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<FlexLayoutServerModule, never, never, never>;
  static ɵinj: i0.ɵɵInjectorDeclaration<FlexLayoutServerModule>;
}
/**
 * Special server-only class to simulate a MediaQueryList and
 * - supports manual activation to simulate mediaQuery matching
 * - manages listeners
 */
declare class ServerMediaQueryList implements MediaQueryList {
  private _mediaQuery;
  private _isActive;
  private _listeners;
  get matches(): boolean;
  get media(): string;
  constructor(_mediaQuery: string, _isActive?: boolean);
  /**
   * Destroy the current list by deactivating the
   * listeners and clearing the internal list
   */
  destroy(): void;
  /** Notify all listeners that 'matches === TRUE' */
  activate(): ServerMediaQueryList;
  /** Notify all listeners that 'matches === false' */
  deactivate(): ServerMediaQueryList;
  /** Add a listener to our internal list to activate later */
  addListener(listener: MediaQueryListListener): void;
  /** Don't need to remove listeners in the server environment */
  removeListener(_: MediaQueryListListener | null): void;
  addEventListener<K extends keyof MediaQueryListEventMap>(_: K, __: (this: MediaQueryList, ev: MediaQueryListEventMap[K]) => any, ___?: boolean | AddEventListenerOptions): void;
  removeEventListener<K extends keyof MediaQueryListEventMap>(_: K, __: (this: MediaQueryList, ev: MediaQueryListEventMap[K]) => any, ___?: boolean | EventListenerOptions): void;
  dispatchEvent(_: Event): boolean;
  onchange: MediaQueryListListener;
}
/**
 * Special server-only implementation of MatchMedia that uses the above
 * ServerMediaQueryList as its internal representation
 *
 * Also contains methods to activate and deactivate breakpoints
 */
declare class ServerMatchMedia extends ɵMatchMedia {
  protected _zone: NgZone;
  protected _platformId: Object;
  protected _document: any;
  protected breakpoints: BreakPoint[];
  protected layoutConfig: LayoutConfigOptions;
  private _activeBreakpoints;
  constructor(_zone: NgZone, _platformId: Object, _document: any, breakpoints: BreakPoint[], layoutConfig: LayoutConfigOptions);
  /** Activate the specified breakpoint if we're on the server, no-op otherwise */
  activateBreakpoint(bp: BreakPoint): void;
  /** Deactivate the specified breakpoint if we're on the server, no-op otherwise */
  deactivateBreakpoint(bp: BreakPoint): void;
  /**
   * Call window.matchMedia() to build a MediaQueryList; which
   * supports 0..n listeners for activation/deactivation
   */
  protected buildMQL(query: string): ServerMediaQueryList;
  static ɵfac: i0.ɵɵFactoryDeclaration<ServerMatchMedia, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
type MediaQueryListListener = ((this: MediaQueryList, ev: MediaQueryListEvent) => any) | null;
/**
 * Activate all of the registered breakpoints in sequence, and then
 * retrieve the associated stylings from the virtual stylesheet
 * @param serverSheet the virtual stylesheet that stores styles for each
 *        element
 * @param mediaController the MatchMedia service to activate/deactivate breakpoints
 * @param breakpoints the registered breakpoints to activate/deactivate
 * @param layoutConfig the library config, and specifically the breakpoints to activate
 */
export declare function generateStaticFlexLayoutStyles(serverSheet: StylesheetMap, mediaController: ServerMatchMedia, breakpoints: BreakPoint[]): string;
/**
 * Create a style tag populated with the dynamic stylings from Flex
 * components and attach it to the head of the DOM
 */
export declare function FLEX_SSR_SERIALIZER_FACTORY(serverSheet: StylesheetMap, mediaController: ServerMatchMedia, _document: Document, breakpoints: BreakPoint[]): () => void;
/**
 *  Provider to set static styles on the server
 */
export declare const SERVER_PROVIDERS: ({
  provide: InjectionToken<() => void>;
  useFactory: typeof FLEX_SSR_SERIALIZER_FACTORY;
  deps: (typeof ɵMatchMedia | InjectionToken<Document> | typeof StylesheetMap)[];
  multi: boolean;
  useValue?: undefined;
  useClass?: undefined;
} | {
  provide: InjectionToken<boolean>;
  useValue: boolean;
  useFactory?: undefined;
  deps?: undefined;
  multi?: undefined;
  useClass?: undefined;
} | {
  provide: typeof ɵMatchMedia;
  useClass: typeof ServerMatchMedia;
  useFactory?: undefined;
  deps?: undefined;
  multi?: undefined;
  useValue?: undefined;
})[];
export type StyleSheet = Map<HTMLElement, Map<string, string | number>>;
export type ClassMap = Map<HTMLElement, string>;
export {};
//# sourceMappingURL=angular-flex-layout-server.d.ts.map