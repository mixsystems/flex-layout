/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/**
 * Applies CSS prefixes to appropriate style keys.
 *
 * Note: `-ms-`, `-moz` and `-webkit-box` are no longer supported. e.g.
 *    {
 *      display: -webkit-flex;     NEW - Safari 6.1+. iOS 7.1+, BB10
 *      display: flex;             NEW, Spec - Firefox, Chrome, Opera
 *      // display: -webkit-box;   OLD - iOS 6-, Safari 3.1-6, BB7
 *      // display: -ms-flexbox;   TWEENER - IE 10
 *      // display: -moz-flexbox;  OLD - Firefox
 *    }
 */
export declare function applyCssPrefixes(target: {
  [key: string]: any | null;
}): {
  [key: string]: any;
};
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
export declare const INLINE = "inline";
export declare const LAYOUT_VALUES: string[];
/**
 * Validate the direction|'direction wrap' value and then update the host's inline flexbox styles
 */
export declare function buildLayoutCSS(value: string): {
  display: string;
  'box-sizing': string;
  'flex-direction': string;
  'flex-wrap': string | null;
};
/**
 * Validate the value to be one of the acceptable value options
 * Use default fallback of 'row'
 */
export declare function validateValue(value: string): [string, string, boolean];
/**
 * Determine if the validated, flex-direction value specifies
 * a horizontal/row flow.
 */
export declare function isFlowHorizontal(value: string): boolean;
/**
 * Convert layout-wrap='<value>' to expected flex-wrap style
 */
export declare function validateWrapValue(value: string): string;
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/**
 * Extends an object with the *enumerable* and *own* properties of one or more source objects,
 * similar to Object.assign.
 *
 * @param dest The object which will have properties copied to it.
 * @param sources The source objects from which properties will be copied.
 */
export declare function extendObject(dest: any, ...sources: any[]): any;
//# sourceMappingURL=angular-flex-layout-_private-utils.d.ts.map