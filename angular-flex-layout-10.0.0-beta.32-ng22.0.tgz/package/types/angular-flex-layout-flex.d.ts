import * as i0 from "@angular/core";
import { AfterContentInit, ElementRef, NgZone, OnChanges, OnDestroy, OnInit } from "@angular/core";
import * as i9 from "@angular/flex-layout/core";
import { BaseDirective2, ElementMatcher, LayoutConfigOptions, MediaMarshaller, StyleBuilder, StyleDefinition, StyleUtils } from "@angular/flex-layout/core";
import * as i10 from "@angular/cdk/bidi";
import { Directionality } from "@angular/cdk/bidi";
import { Subject } from "rxjs";
export declare class LayoutStyleBuilder extends StyleBuilder {
  buildStyles(input: string): {
    display: string;
    'box-sizing': string;
    'flex-direction': string;
    'flex-wrap': string | null;
  };
  static ɵfac: i0.ɵɵFactoryDeclaration<LayoutStyleBuilder, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * 'layout' flexbox styling directive
 * Defines the positioning flow direction for the child elements: row or column
 * Optional values: column or row (default)
 * @see https://css-tricks.com/almanac/properties/f/flex-direction/
 *
 */
export declare class LayoutDirective extends BaseDirective2 implements OnChanges {
  protected DIRECTIVE_KEY: string;
  constructor(elRef: ElementRef, styleUtils: StyleUtils, styleBuilder: LayoutStyleBuilder, marshal: MediaMarshaller);
  protected styleCache: Map<string, StyleDefinition>;
  static ɵfac: i0.ɵɵFactoryDeclaration<LayoutDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<LayoutDirective, never, never, {}, {}, never, never, true, never>;
}
export declare class DefaultLayoutDirective extends LayoutDirective {
  protected inputs: string[];
  static ɵfac: i0.ɵɵFactoryDeclaration<DefaultLayoutDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DefaultLayoutDirective, "  [fxLayout], [fxLayout.xs], [fxLayout.sm], [fxLayout.md],  [fxLayout.lg], [fxLayout.xl], [fxLayout.lt-sm], [fxLayout.lt-md],  [fxLayout.lt-lg], [fxLayout.lt-xl], [fxLayout.gt-xs], [fxLayout.gt-sm],  [fxLayout.gt-md], [fxLayout.gt-lg]", never, {
    "fxLayout": {
      "alias": "fxLayout";
      "required": false;
    };
    "fxLayout.xs": {
      "alias": "fxLayout.xs";
      "required": false;
    };
    "fxLayout.sm": {
      "alias": "fxLayout.sm";
      "required": false;
    };
    "fxLayout.md": {
      "alias": "fxLayout.md";
      "required": false;
    };
    "fxLayout.lg": {
      "alias": "fxLayout.lg";
      "required": false;
    };
    "fxLayout.xl": {
      "alias": "fxLayout.xl";
      "required": false;
    };
    "fxLayout.lt-sm": {
      "alias": "fxLayout.lt-sm";
      "required": false;
    };
    "fxLayout.lt-md": {
      "alias": "fxLayout.lt-md";
      "required": false;
    };
    "fxLayout.lt-lg": {
      "alias": "fxLayout.lt-lg";
      "required": false;
    };
    "fxLayout.lt-xl": {
      "alias": "fxLayout.lt-xl";
      "required": false;
    };
    "fxLayout.gt-xs": {
      "alias": "fxLayout.gt-xs";
      "required": false;
    };
    "fxLayout.gt-sm": {
      "alias": "fxLayout.gt-sm";
      "required": false;
    };
    "fxLayout.gt-md": {
      "alias": "fxLayout.gt-md";
      "required": false;
    };
    "fxLayout.gt-lg": {
      "alias": "fxLayout.gt-lg";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
export interface LayoutGapParent {
  directionality: string;
  items: HTMLElement[];
  layout: string;
}
export declare class LayoutGapStyleBuilder extends StyleBuilder {
  private _styler;
  constructor(_styler: StyleUtils);
  buildStyles(gapValue: string, parent: LayoutGapParent): StyleDefinition;
  sideEffect(gapValue: string, _styles: StyleDefinition, parent: LayoutGapParent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<LayoutGapStyleBuilder, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * 'layout-padding' styling directive
 *  Defines padding of child elements in a layout container
 */
export declare class LayoutGapDirective extends BaseDirective2 implements AfterContentInit, OnDestroy {
  protected zone: NgZone;
  protected directionality: Directionality;
  protected styleUtils: StyleUtils;
  protected layout: string;
  protected DIRECTIVE_KEY: string;
  protected observerSubject: Subject<void>;
  /** Special accessor to query for all child 'element' nodes regardless of type, class, etc */
  protected get childrenNodes(): HTMLElement[];
  constructor(elRef: ElementRef, zone: NgZone, directionality: Directionality, styleUtils: StyleUtils, styleBuilder: LayoutGapStyleBuilder, marshal: MediaMarshaller);
  ngAfterContentInit(): void;
  ngOnDestroy(): void;
  /**
   * Cache the parent container 'flex-direction' and update the 'margin' styles
   */
  protected onLayoutChange(matcher: ElementMatcher): void;
  /**
   *
   */
  protected updateWithValue(value: string): void;
  /** We need to override clearStyles because in most cases mru isn't populated */
  protected clearStyles(): void;
  /** Determine if an element will show or hide based on current activation */
  protected willDisplay(source: HTMLElement): boolean;
  protected buildChildObservable(): void;
  protected observer?: MutationObserver;
  static ɵfac: i0.ɵɵFactoryDeclaration<LayoutGapDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<LayoutGapDirective, never, never, {}, {}, never, never, true, never>;
}
export declare class DefaultLayoutGapDirective extends LayoutGapDirective {
  protected inputs: string[];
  static ɵfac: i0.ɵɵFactoryDeclaration<DefaultLayoutGapDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DefaultLayoutGapDirective, "  [fxLayoutGap], [fxLayoutGap.xs], [fxLayoutGap.sm], [fxLayoutGap.md],  [fxLayoutGap.lg], [fxLayoutGap.xl], [fxLayoutGap.lt-sm], [fxLayoutGap.lt-md],  [fxLayoutGap.lt-lg], [fxLayoutGap.lt-xl], [fxLayoutGap.gt-xs], [fxLayoutGap.gt-sm],  [fxLayoutGap.gt-md], [fxLayoutGap.gt-lg]", never, {
    "fxLayoutGap": {
      "alias": "fxLayoutGap";
      "required": false;
    };
    "fxLayoutGap.xs": {
      "alias": "fxLayoutGap.xs";
      "required": false;
    };
    "fxLayoutGap.sm": {
      "alias": "fxLayoutGap.sm";
      "required": false;
    };
    "fxLayoutGap.md": {
      "alias": "fxLayoutGap.md";
      "required": false;
    };
    "fxLayoutGap.lg": {
      "alias": "fxLayoutGap.lg";
      "required": false;
    };
    "fxLayoutGap.xl": {
      "alias": "fxLayoutGap.xl";
      "required": false;
    };
    "fxLayoutGap.lt-sm": {
      "alias": "fxLayoutGap.lt-sm";
      "required": false;
    };
    "fxLayoutGap.lt-md": {
      "alias": "fxLayoutGap.lt-md";
      "required": false;
    };
    "fxLayoutGap.lt-lg": {
      "alias": "fxLayoutGap.lt-lg";
      "required": false;
    };
    "fxLayoutGap.lt-xl": {
      "alias": "fxLayoutGap.lt-xl";
      "required": false;
    };
    "fxLayoutGap.gt-xs": {
      "alias": "fxLayoutGap.gt-xs";
      "required": false;
    };
    "fxLayoutGap.gt-sm": {
      "alias": "fxLayoutGap.gt-sm";
      "required": false;
    };
    "fxLayoutGap.gt-md": {
      "alias": "fxLayoutGap.gt-md";
      "required": false;
    };
    "fxLayoutGap.gt-lg": {
      "alias": "fxLayoutGap.gt-lg";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
export interface LayoutAlignParent {
  layout: string;
  inline: boolean;
}
export declare class LayoutAlignStyleBuilder extends StyleBuilder {
  buildStyles(align: string, parent: LayoutAlignParent): StyleDefinition;
  static ɵfac: i0.ɵɵFactoryDeclaration<LayoutAlignStyleBuilder, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * 'layout-align' flexbox styling directive
 *  Defines positioning of child elements along main and cross axis in a layout container
 *  Optional values: {main-axis} values or {main-axis cross-axis} value pairs
 *
 *  @see https://css-tricks.com/almanac/properties/j/justify-content/
 *  @see https://css-tricks.com/almanac/properties/a/align-items/
 *  @see https://css-tricks.com/almanac/properties/a/align-content/
 */
export declare class LayoutAlignDirective extends BaseDirective2 {
  protected DIRECTIVE_KEY: string;
  protected layout: string;
  protected inline: boolean;
  constructor(elRef: ElementRef, styleUtils: StyleUtils, styleBuilder: LayoutAlignStyleBuilder, marshal: MediaMarshaller);
  /**
   *
   */
  protected updateWithValue(value: string): void;
  /**
   * Cache the parent container 'flex-direction' and update the 'flex' styles
   */
  protected onLayoutChange(matcher: ElementMatcher): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<LayoutAlignDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<LayoutAlignDirective, never, never, {}, {}, never, never, true, never>;
}
export declare class DefaultLayoutAlignDirective extends LayoutAlignDirective {
  protected inputs: string[];
  static ɵfac: i0.ɵɵFactoryDeclaration<DefaultLayoutAlignDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DefaultLayoutAlignDirective, "  [fxLayoutAlign], [fxLayoutAlign.xs], [fxLayoutAlign.sm], [fxLayoutAlign.md],  [fxLayoutAlign.lg], [fxLayoutAlign.xl], [fxLayoutAlign.lt-sm], [fxLayoutAlign.lt-md],  [fxLayoutAlign.lt-lg], [fxLayoutAlign.lt-xl], [fxLayoutAlign.gt-xs], [fxLayoutAlign.gt-sm],  [fxLayoutAlign.gt-md], [fxLayoutAlign.gt-lg]", never, {
    "fxLayoutAlign": {
      "alias": "fxLayoutAlign";
      "required": false;
    };
    "fxLayoutAlign.xs": {
      "alias": "fxLayoutAlign.xs";
      "required": false;
    };
    "fxLayoutAlign.sm": {
      "alias": "fxLayoutAlign.sm";
      "required": false;
    };
    "fxLayoutAlign.md": {
      "alias": "fxLayoutAlign.md";
      "required": false;
    };
    "fxLayoutAlign.lg": {
      "alias": "fxLayoutAlign.lg";
      "required": false;
    };
    "fxLayoutAlign.xl": {
      "alias": "fxLayoutAlign.xl";
      "required": false;
    };
    "fxLayoutAlign.lt-sm": {
      "alias": "fxLayoutAlign.lt-sm";
      "required": false;
    };
    "fxLayoutAlign.lt-md": {
      "alias": "fxLayoutAlign.lt-md";
      "required": false;
    };
    "fxLayoutAlign.lt-lg": {
      "alias": "fxLayoutAlign.lt-lg";
      "required": false;
    };
    "fxLayoutAlign.lt-xl": {
      "alias": "fxLayoutAlign.lt-xl";
      "required": false;
    };
    "fxLayoutAlign.gt-xs": {
      "alias": "fxLayoutAlign.gt-xs";
      "required": false;
    };
    "fxLayoutAlign.gt-sm": {
      "alias": "fxLayoutAlign.gt-sm";
      "required": false;
    };
    "fxLayoutAlign.gt-md": {
      "alias": "fxLayoutAlign.gt-md";
      "required": false;
    };
    "fxLayoutAlign.gt-lg": {
      "alias": "fxLayoutAlign.gt-lg";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
export declare class FlexOrderStyleBuilder extends StyleBuilder {
  buildStyles(value: string): {
    order: string | number;
  };
  static ɵfac: i0.ɵɵFactoryDeclaration<FlexOrderStyleBuilder, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * 'flex-order' flexbox styling directive
 * Configures the positional ordering of the element in a sorted layout container
 * @see https://css-tricks.com/almanac/properties/o/order/
 */
export declare class FlexOrderDirective extends BaseDirective2 implements OnChanges {
  protected DIRECTIVE_KEY: string;
  constructor(elRef: ElementRef, styleUtils: StyleUtils, styleBuilder: FlexOrderStyleBuilder, marshal: MediaMarshaller);
  protected styleCache: Map<string, StyleDefinition>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FlexOrderDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<FlexOrderDirective, never, never, {}, {}, never, never, true, never>;
}
export declare class DefaultFlexOrderDirective extends FlexOrderDirective {
  protected inputs: string[];
  static ɵfac: i0.ɵɵFactoryDeclaration<DefaultFlexOrderDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DefaultFlexOrderDirective, "  [fxFlexOrder], [fxFlexOrder.xs], [fxFlexOrder.sm], [fxFlexOrder.md],  [fxFlexOrder.lg], [fxFlexOrder.xl], [fxFlexOrder.lt-sm], [fxFlexOrder.lt-md],  [fxFlexOrder.lt-lg], [fxFlexOrder.lt-xl], [fxFlexOrder.gt-xs], [fxFlexOrder.gt-sm],  [fxFlexOrder.gt-md], [fxFlexOrder.gt-lg]", never, {
    "fxFlexOrder": {
      "alias": "fxFlexOrder";
      "required": false;
    };
    "fxFlexOrder.xs": {
      "alias": "fxFlexOrder.xs";
      "required": false;
    };
    "fxFlexOrder.sm": {
      "alias": "fxFlexOrder.sm";
      "required": false;
    };
    "fxFlexOrder.md": {
      "alias": "fxFlexOrder.md";
      "required": false;
    };
    "fxFlexOrder.lg": {
      "alias": "fxFlexOrder.lg";
      "required": false;
    };
    "fxFlexOrder.xl": {
      "alias": "fxFlexOrder.xl";
      "required": false;
    };
    "fxFlexOrder.lt-sm": {
      "alias": "fxFlexOrder.lt-sm";
      "required": false;
    };
    "fxFlexOrder.lt-md": {
      "alias": "fxFlexOrder.lt-md";
      "required": false;
    };
    "fxFlexOrder.lt-lg": {
      "alias": "fxFlexOrder.lt-lg";
      "required": false;
    };
    "fxFlexOrder.lt-xl": {
      "alias": "fxFlexOrder.lt-xl";
      "required": false;
    };
    "fxFlexOrder.gt-xs": {
      "alias": "fxFlexOrder.gt-xs";
      "required": false;
    };
    "fxFlexOrder.gt-sm": {
      "alias": "fxFlexOrder.gt-sm";
      "required": false;
    };
    "fxFlexOrder.gt-md": {
      "alias": "fxFlexOrder.gt-md";
      "required": false;
    };
    "fxFlexOrder.gt-lg": {
      "alias": "fxFlexOrder.gt-lg";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
export interface FlexOffsetParent {
  layout: string;
  isRtl: boolean;
}
export declare class FlexOffsetStyleBuilder extends StyleBuilder {
  buildStyles(offset: string, parent: FlexOffsetParent): StyleDefinition;
  static ɵfac: i0.ɵɵFactoryDeclaration<FlexOffsetStyleBuilder, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * 'flex-offset' flexbox styling directive
 * Configures the 'margin-left' of the element in a layout container
 */
export declare class FlexOffsetDirective extends BaseDirective2 implements OnChanges {
  protected directionality: Directionality;
  protected DIRECTIVE_KEY: string;
  constructor(elRef: ElementRef, directionality: Directionality, styleBuilder: FlexOffsetStyleBuilder, marshal: MediaMarshaller, styler: StyleUtils);
  /**
   * Using the current fxFlexOffset value, update the inline CSS
   * NOTE: this will assign `margin-left` if the parent flex-direction == 'row',
   *       otherwise `margin-top` is used for the offset.
   */
  protected updateWithValue(value?: string | number): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<FlexOffsetDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<FlexOffsetDirective, never, never, {}, {}, never, never, true, never>;
}
export declare class DefaultFlexOffsetDirective extends FlexOffsetDirective {
  protected inputs: string[];
  static ɵfac: i0.ɵɵFactoryDeclaration<DefaultFlexOffsetDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DefaultFlexOffsetDirective, "  [fxFlexOffset], [fxFlexOffset.xs], [fxFlexOffset.sm], [fxFlexOffset.md],  [fxFlexOffset.lg], [fxFlexOffset.xl], [fxFlexOffset.lt-sm], [fxFlexOffset.lt-md],  [fxFlexOffset.lt-lg], [fxFlexOffset.lt-xl], [fxFlexOffset.gt-xs], [fxFlexOffset.gt-sm],  [fxFlexOffset.gt-md], [fxFlexOffset.gt-lg]", never, {
    "fxFlexOffset": {
      "alias": "fxFlexOffset";
      "required": false;
    };
    "fxFlexOffset.xs": {
      "alias": "fxFlexOffset.xs";
      "required": false;
    };
    "fxFlexOffset.sm": {
      "alias": "fxFlexOffset.sm";
      "required": false;
    };
    "fxFlexOffset.md": {
      "alias": "fxFlexOffset.md";
      "required": false;
    };
    "fxFlexOffset.lg": {
      "alias": "fxFlexOffset.lg";
      "required": false;
    };
    "fxFlexOffset.xl": {
      "alias": "fxFlexOffset.xl";
      "required": false;
    };
    "fxFlexOffset.lt-sm": {
      "alias": "fxFlexOffset.lt-sm";
      "required": false;
    };
    "fxFlexOffset.lt-md": {
      "alias": "fxFlexOffset.lt-md";
      "required": false;
    };
    "fxFlexOffset.lt-lg": {
      "alias": "fxFlexOffset.lt-lg";
      "required": false;
    };
    "fxFlexOffset.lt-xl": {
      "alias": "fxFlexOffset.lt-xl";
      "required": false;
    };
    "fxFlexOffset.gt-xs": {
      "alias": "fxFlexOffset.gt-xs";
      "required": false;
    };
    "fxFlexOffset.gt-sm": {
      "alias": "fxFlexOffset.gt-sm";
      "required": false;
    };
    "fxFlexOffset.gt-md": {
      "alias": "fxFlexOffset.gt-md";
      "required": false;
    };
    "fxFlexOffset.gt-lg": {
      "alias": "fxFlexOffset.gt-lg";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
export declare class FlexFillStyleBuilder extends StyleBuilder {
  buildStyles(_input: string): {
    margin: number;
    width: string;
    height: string;
    'min-width': string;
    'min-height': string;
  };
  static ɵfac: i0.ɵɵFactoryDeclaration<FlexFillStyleBuilder, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * 'fxFill' flexbox styling directive
 *  Maximizes width and height of element in a layout container
 *
 *  NOTE: fxFill is NOT responsive API!!
 */
export declare class FlexFillDirective extends BaseDirective2 {
  constructor(elRef: ElementRef, styleUtils: StyleUtils, styleBuilder: FlexFillStyleBuilder, marshal: MediaMarshaller);
  protected styleCache: Map<string, StyleDefinition>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FlexFillDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<FlexFillDirective, "[fxFill], [fxFlexFill]", never, {}, {}, never, never, false, never>;
}
export declare class FlexAlignStyleBuilder extends StyleBuilder {
  buildStyles(input: string): StyleDefinition;
  static ɵfac: i0.ɵɵFactoryDeclaration<FlexAlignStyleBuilder, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * 'flex-align' flexbox styling directive
 * Allows element-specific overrides for cross-axis alignments in a layout container
 * @see https://css-tricks.com/almanac/properties/a/align-self/
 */
export declare class FlexAlignDirective extends BaseDirective2 {
  protected DIRECTIVE_KEY: string;
  constructor(elRef: ElementRef, styleUtils: StyleUtils, styleBuilder: FlexAlignStyleBuilder, marshal: MediaMarshaller);
  protected styleCache: Map<string, StyleDefinition>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FlexAlignDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<FlexAlignDirective, never, never, {}, {}, never, never, true, never>;
}
export declare class DefaultFlexAlignDirective extends FlexAlignDirective {
  protected inputs: string[];
  static ɵfac: i0.ɵɵFactoryDeclaration<DefaultFlexAlignDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DefaultFlexAlignDirective, "  [fxFlexAlign], [fxFlexAlign.xs], [fxFlexAlign.sm], [fxFlexAlign.md],  [fxFlexAlign.lg], [fxFlexAlign.xl], [fxFlexAlign.lt-sm], [fxFlexAlign.lt-md],  [fxFlexAlign.lt-lg], [fxFlexAlign.lt-xl], [fxFlexAlign.gt-xs], [fxFlexAlign.gt-sm],  [fxFlexAlign.gt-md], [fxFlexAlign.gt-lg]", never, {
    "fxFlexAlign": {
      "alias": "fxFlexAlign";
      "required": false;
    };
    "fxFlexAlign.xs": {
      "alias": "fxFlexAlign.xs";
      "required": false;
    };
    "fxFlexAlign.sm": {
      "alias": "fxFlexAlign.sm";
      "required": false;
    };
    "fxFlexAlign.md": {
      "alias": "fxFlexAlign.md";
      "required": false;
    };
    "fxFlexAlign.lg": {
      "alias": "fxFlexAlign.lg";
      "required": false;
    };
    "fxFlexAlign.xl": {
      "alias": "fxFlexAlign.xl";
      "required": false;
    };
    "fxFlexAlign.lt-sm": {
      "alias": "fxFlexAlign.lt-sm";
      "required": false;
    };
    "fxFlexAlign.lt-md": {
      "alias": "fxFlexAlign.lt-md";
      "required": false;
    };
    "fxFlexAlign.lt-lg": {
      "alias": "fxFlexAlign.lt-lg";
      "required": false;
    };
    "fxFlexAlign.lt-xl": {
      "alias": "fxFlexAlign.lt-xl";
      "required": false;
    };
    "fxFlexAlign.gt-xs": {
      "alias": "fxFlexAlign.gt-xs";
      "required": false;
    };
    "fxFlexAlign.gt-sm": {
      "alias": "fxFlexAlign.gt-sm";
      "required": false;
    };
    "fxFlexAlign.gt-md": {
      "alias": "fxFlexAlign.gt-md";
      "required": false;
    };
    "fxFlexAlign.gt-lg": {
      "alias": "fxFlexAlign.gt-lg";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
interface FlexBuilderParent {
  direction: string;
  hasWrap: boolean;
}
export declare class FlexStyleBuilder extends StyleBuilder {
  protected layoutConfig: LayoutConfigOptions;
  constructor(layoutConfig: LayoutConfigOptions);
  buildStyles(input: string, parent: FlexBuilderParent): StyleDefinition;
  static ɵfac: i0.ɵɵFactoryDeclaration<FlexStyleBuilder, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Directive to control the size of a flex item using flex-basis, flex-grow, and flex-shrink.
 * Corresponds to the css `flex` shorthand property.
 *
 * @see https://css-tricks.com/snippets/css/a-guide-to-flexbox/
 */
export declare class FlexDirective extends BaseDirective2 implements OnInit {
  protected layoutConfig: LayoutConfigOptions;
  protected marshal: MediaMarshaller;
  protected DIRECTIVE_KEY: string;
  protected direction?: string;
  protected wrap?: boolean;
  get shrink(): string;
  set shrink(value: string);
  get grow(): string;
  set grow(value: string);
  protected flexGrow: string;
  protected flexShrink: string;
  constructor(elRef: ElementRef, styleUtils: StyleUtils, layoutConfig: LayoutConfigOptions, styleBuilder: FlexStyleBuilder, marshal: MediaMarshaller);
  ngOnInit(): void;
  /**
   * Caches the parent container's 'flex-direction' and updates the element's style.
   * Used as a handler for layout change events from the parent flex container.
   */
  protected onLayoutChange(matcher: ElementMatcher): void;
  /** Input to this is exclusively the basis input value */
  protected updateWithValue(value: string): void;
  /** Trigger a style reflow, usually based on a shrink/grow input event */
  protected triggerReflow(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<FlexDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<FlexDirective, never, never, {
    "shrink": {
      "alias": "fxShrink";
      "required": false;
    };
    "grow": {
      "alias": "fxGrow";
      "required": false;
    };
  }, {}, never, never, true, never>;
}
export declare class DefaultFlexDirective extends FlexDirective {
  protected inputs: string[];
  static ɵfac: i0.ɵɵFactoryDeclaration<DefaultFlexDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DefaultFlexDirective, "  [fxFlex], [fxFlex.xs], [fxFlex.sm], [fxFlex.md],  [fxFlex.lg], [fxFlex.xl], [fxFlex.lt-sm], [fxFlex.lt-md],  [fxFlex.lt-lg], [fxFlex.lt-xl], [fxFlex.gt-xs], [fxFlex.gt-sm],  [fxFlex.gt-md], [fxFlex.gt-lg]", never, {
    "fxFlex": {
      "alias": "fxFlex";
      "required": false;
    };
    "fxFlex.xs": {
      "alias": "fxFlex.xs";
      "required": false;
    };
    "fxFlex.sm": {
      "alias": "fxFlex.sm";
      "required": false;
    };
    "fxFlex.md": {
      "alias": "fxFlex.md";
      "required": false;
    };
    "fxFlex.lg": {
      "alias": "fxFlex.lg";
      "required": false;
    };
    "fxFlex.xl": {
      "alias": "fxFlex.xl";
      "required": false;
    };
    "fxFlex.lt-sm": {
      "alias": "fxFlex.lt-sm";
      "required": false;
    };
    "fxFlex.lt-md": {
      "alias": "fxFlex.lt-md";
      "required": false;
    };
    "fxFlex.lt-lg": {
      "alias": "fxFlex.lt-lg";
      "required": false;
    };
    "fxFlex.lt-xl": {
      "alias": "fxFlex.lt-xl";
      "required": false;
    };
    "fxFlex.gt-xs": {
      "alias": "fxFlex.gt-xs";
      "required": false;
    };
    "fxFlex.gt-sm": {
      "alias": "fxFlex.gt-sm";
      "required": false;
    };
    "fxFlex.gt-md": {
      "alias": "fxFlex.gt-md";
      "required": false;
    };
    "fxFlex.gt-lg": {
      "alias": "fxFlex.gt-lg";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
/**
 * *****************************************************************
 * Define module for the Flex API
 * *****************************************************************
 */
export declare class FlexModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<FlexModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<FlexModule, [typeof DefaultLayoutDirective, typeof DefaultLayoutGapDirective, typeof DefaultLayoutAlignDirective, typeof DefaultFlexOrderDirective, typeof DefaultFlexOffsetDirective, typeof FlexFillDirective, typeof DefaultFlexAlignDirective, typeof DefaultFlexDirective], [typeof i9.CoreModule, typeof i10.BidiModule], [typeof DefaultLayoutDirective, typeof DefaultLayoutGapDirective, typeof DefaultLayoutAlignDirective, typeof DefaultFlexOrderDirective, typeof DefaultFlexOffsetDirective, typeof FlexFillDirective, typeof DefaultFlexAlignDirective, typeof DefaultFlexDirective]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<FlexModule>;
}
export {};
//# sourceMappingURL=angular-flex-layout-flex.d.ts.map