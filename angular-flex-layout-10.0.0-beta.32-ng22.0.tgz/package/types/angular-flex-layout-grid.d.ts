import * as i0 from "@angular/core";
import { ElementRef } from "@angular/core";
import * as i12 from "@angular/flex-layout/core";
import { BaseDirective2, MediaMarshaller, StyleBuilder, StyleDefinition, StyleUtils } from "@angular/flex-layout/core";
import { BooleanInput } from "@angular/cdk/coercion";
export declare class GridAlignStyleBuilder extends StyleBuilder {
  buildStyles(input: string): {
    [key: string]: string;
  };
  static ɵfac: i0.ɵɵFactoryDeclaration<GridAlignStyleBuilder, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare class GridAlignDirective extends BaseDirective2 {
  protected DIRECTIVE_KEY: string;
  constructor(elementRef: ElementRef, styleBuilder: GridAlignStyleBuilder, styler: StyleUtils, marshal: MediaMarshaller);
  protected styleCache: Map<string, StyleDefinition>;
  static ɵfac: i0.ɵɵFactoryDeclaration<GridAlignDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<GridAlignDirective, never, never, {}, {}, never, never, true, never>;
}
/**
 * 'align' CSS Grid styling directive for grid children
 *  Defines positioning of child elements along row and column axis in a grid container
 *  Optional values: {row-axis} values or {row-axis column-axis} value pairs
 *
 *  @see https://css-tricks.com/snippets/css/complete-guide-grid/#prop-justify-self
 *  @see https://css-tricks.com/snippets/css/complete-guide-grid/#prop-align-self
 */
export declare class DefaultGridAlignDirective extends GridAlignDirective {
  protected inputs: string[];
  static ɵfac: i0.ɵɵFactoryDeclaration<DefaultGridAlignDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DefaultGridAlignDirective, "  [gdGridAlign],  [gdGridAlign.xs], [gdGridAlign.sm], [gdGridAlign.md], [gdGridAlign.lg],[gdGridAlign.xl],  [gdGridAlign.lt-sm], [gdGridAlign.lt-md], [gdGridAlign.lt-lg], [gdGridAlign.lt-xl],  [gdGridAlign.gt-xs], [gdGridAlign.gt-sm], [gdGridAlign.gt-md], [gdGridAlign.gt-lg]", never, {
    "gdGridAlign": {
      "alias": "gdGridAlign";
      "required": false;
    };
    "gdGridAlign.xs": {
      "alias": "gdGridAlign.xs";
      "required": false;
    };
    "gdGridAlign.sm": {
      "alias": "gdGridAlign.sm";
      "required": false;
    };
    "gdGridAlign.md": {
      "alias": "gdGridAlign.md";
      "required": false;
    };
    "gdGridAlign.lg": {
      "alias": "gdGridAlign.lg";
      "required": false;
    };
    "gdGridAlign.xl": {
      "alias": "gdGridAlign.xl";
      "required": false;
    };
    "gdGridAlign.lt-sm": {
      "alias": "gdGridAlign.lt-sm";
      "required": false;
    };
    "gdGridAlign.lt-md": {
      "alias": "gdGridAlign.lt-md";
      "required": false;
    };
    "gdGridAlign.lt-lg": {
      "alias": "gdGridAlign.lt-lg";
      "required": false;
    };
    "gdGridAlign.lt-xl": {
      "alias": "gdGridAlign.lt-xl";
      "required": false;
    };
    "gdGridAlign.gt-xs": {
      "alias": "gdGridAlign.gt-xs";
      "required": false;
    };
    "gdGridAlign.gt-sm": {
      "alias": "gdGridAlign.gt-sm";
      "required": false;
    };
    "gdGridAlign.gt-md": {
      "alias": "gdGridAlign.gt-md";
      "required": false;
    };
    "gdGridAlign.gt-lg": {
      "alias": "gdGridAlign.gt-lg";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
export interface GridAlignColumnsParent {
  inline: boolean;
}
export declare class GridAlignColumnsStyleBuilder extends StyleBuilder {
  buildStyles(input: string, parent: GridAlignColumnsParent): StyleDefinition;
  static ɵfac: i0.ɵɵFactoryDeclaration<GridAlignColumnsStyleBuilder, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare class GridAlignColumnsDirective extends BaseDirective2 {
  protected DIRECTIVE_KEY: string;
  get inline(): boolean;
  set inline(val: BooleanInput);
  protected _inline: boolean;
  constructor(elementRef: ElementRef, styleBuilder: GridAlignColumnsStyleBuilder, styler: StyleUtils, marshal: MediaMarshaller);
  protected updateWithValue(value: string): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<GridAlignColumnsDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<GridAlignColumnsDirective, never, never, {
    "inline": {
      "alias": "gdInline";
      "required": false;
    };
  }, {}, never, never, true, never>;
}
/**
 * 'column alignment' CSS Grid styling directive
 * Configures the alignment in the column direction
 * @see https://css-tricks.com/snippets/css/complete-guide-grid/#article-header-id-19
 * @see https://css-tricks.com/snippets/css/complete-guide-grid/#article-header-id-21
 */
export declare class DefaultGridAlignColumnsDirective extends GridAlignColumnsDirective {
  protected inputs: string[];
  static ɵfac: i0.ɵɵFactoryDeclaration<DefaultGridAlignColumnsDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DefaultGridAlignColumnsDirective, "  [gdAlignColumns],  [gdAlignColumns.xs], [gdAlignColumns.sm], [gdAlignColumns.md],  [gdAlignColumns.lg], [gdAlignColumns.xl], [gdAlignColumns.lt-sm],  [gdAlignColumns.lt-md], [gdAlignColumns.lt-lg], [gdAlignColumns.lt-xl],  [gdAlignColumns.gt-xs], [gdAlignColumns.gt-sm], [gdAlignColumns.gt-md],  [gdAlignColumns.gt-lg]", never, {
    "gdAlignColumns": {
      "alias": "gdAlignColumns";
      "required": false;
    };
    "gdAlignColumns.xs": {
      "alias": "gdAlignColumns.xs";
      "required": false;
    };
    "gdAlignColumns.sm": {
      "alias": "gdAlignColumns.sm";
      "required": false;
    };
    "gdAlignColumns.md": {
      "alias": "gdAlignColumns.md";
      "required": false;
    };
    "gdAlignColumns.lg": {
      "alias": "gdAlignColumns.lg";
      "required": false;
    };
    "gdAlignColumns.xl": {
      "alias": "gdAlignColumns.xl";
      "required": false;
    };
    "gdAlignColumns.lt-sm": {
      "alias": "gdAlignColumns.lt-sm";
      "required": false;
    };
    "gdAlignColumns.lt-md": {
      "alias": "gdAlignColumns.lt-md";
      "required": false;
    };
    "gdAlignColumns.lt-lg": {
      "alias": "gdAlignColumns.lt-lg";
      "required": false;
    };
    "gdAlignColumns.lt-xl": {
      "alias": "gdAlignColumns.lt-xl";
      "required": false;
    };
    "gdAlignColumns.gt-xs": {
      "alias": "gdAlignColumns.gt-xs";
      "required": false;
    };
    "gdAlignColumns.gt-sm": {
      "alias": "gdAlignColumns.gt-sm";
      "required": false;
    };
    "gdAlignColumns.gt-md": {
      "alias": "gdAlignColumns.gt-md";
      "required": false;
    };
    "gdAlignColumns.gt-lg": {
      "alias": "gdAlignColumns.gt-lg";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
export interface GridAlignRowsParent {
  inline: boolean;
}
export declare class GridAlignRowsStyleBuilder extends StyleBuilder {
  buildStyles(input: string, parent: GridAlignRowsParent): StyleDefinition;
  static ɵfac: i0.ɵɵFactoryDeclaration<GridAlignRowsStyleBuilder, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare class GridAlignRowsDirective extends BaseDirective2 {
  protected DIRECTIVE_KEY: string;
  get inline(): boolean;
  set inline(val: BooleanInput);
  protected _inline: boolean;
  constructor(elementRef: ElementRef, styleBuilder: GridAlignRowsStyleBuilder, styler: StyleUtils, marshal: MediaMarshaller);
  protected updateWithValue(value: string): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<GridAlignRowsDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<GridAlignRowsDirective, never, never, {
    "inline": {
      "alias": "gdInline";
      "required": false;
    };
  }, {}, never, never, true, never>;
}
/**
 * 'row alignment' CSS Grid styling directive
 * Configures the alignment in the row direction
 * @see https://css-tricks.com/snippets/css/complete-guide-grid/#article-header-id-18
 * @see https://css-tricks.com/snippets/css/complete-guide-grid/#article-header-id-20
 */
export declare class DefaultGridAlignRowsDirective extends GridAlignRowsDirective {
  protected inputs: string[];
  static ɵfac: i0.ɵɵFactoryDeclaration<DefaultGridAlignRowsDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DefaultGridAlignRowsDirective, "  [gdAlignRows],  [gdAlignRows.xs], [gdAlignRows.sm], [gdAlignRows.md],  [gdAlignRows.lg], [gdAlignRows.xl], [gdAlignRows.lt-sm],  [gdAlignRows.lt-md], [gdAlignRows.lt-lg], [gdAlignRows.lt-xl],  [gdAlignRows.gt-xs], [gdAlignRows.gt-sm], [gdAlignRows.gt-md],  [gdAlignRows.gt-lg]", never, {
    "gdAlignRows": {
      "alias": "gdAlignRows";
      "required": false;
    };
    "gdAlignRows.xs": {
      "alias": "gdAlignRows.xs";
      "required": false;
    };
    "gdAlignRows.sm": {
      "alias": "gdAlignRows.sm";
      "required": false;
    };
    "gdAlignRows.md": {
      "alias": "gdAlignRows.md";
      "required": false;
    };
    "gdAlignRows.lg": {
      "alias": "gdAlignRows.lg";
      "required": false;
    };
    "gdAlignRows.xl": {
      "alias": "gdAlignRows.xl";
      "required": false;
    };
    "gdAlignRows.lt-sm": {
      "alias": "gdAlignRows.lt-sm";
      "required": false;
    };
    "gdAlignRows.lt-md": {
      "alias": "gdAlignRows.lt-md";
      "required": false;
    };
    "gdAlignRows.lt-lg": {
      "alias": "gdAlignRows.lt-lg";
      "required": false;
    };
    "gdAlignRows.lt-xl": {
      "alias": "gdAlignRows.lt-xl";
      "required": false;
    };
    "gdAlignRows.gt-xs": {
      "alias": "gdAlignRows.gt-xs";
      "required": false;
    };
    "gdAlignRows.gt-sm": {
      "alias": "gdAlignRows.gt-sm";
      "required": false;
    };
    "gdAlignRows.gt-md": {
      "alias": "gdAlignRows.gt-md";
      "required": false;
    };
    "gdAlignRows.gt-lg": {
      "alias": "gdAlignRows.gt-lg";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
export declare class GridAreaStyleBuilder extends StyleBuilder {
  buildStyles(input: string): {
    'grid-area': string;
  };
  static ɵfac: i0.ɵɵFactoryDeclaration<GridAreaStyleBuilder, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare class GridAreaDirective extends BaseDirective2 {
  protected DIRECTIVE_KEY: string;
  constructor(elRef: ElementRef, styleUtils: StyleUtils, styleBuilder: GridAreaStyleBuilder, marshal: MediaMarshaller);
  protected styleCache: Map<string, StyleDefinition>;
  static ɵfac: i0.ɵɵFactoryDeclaration<GridAreaDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<GridAreaDirective, never, never, {}, {}, never, never, true, never>;
}
/**
 * 'grid-area' CSS Grid styling directive
 * Configures the name or position of an element within the grid
 * @see https://css-tricks.com/snippets/css/complete-guide-grid/#article-header-id-27
 */
export declare class DefaultGridAreaDirective extends GridAreaDirective {
  protected inputs: string[];
  static ɵfac: i0.ɵɵFactoryDeclaration<DefaultGridAreaDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DefaultGridAreaDirective, "  [gdArea],  [gdArea.xs], [gdArea.sm], [gdArea.md], [gdArea.lg], [gdArea.xl],  [gdArea.lt-sm], [gdArea.lt-md], [gdArea.lt-lg], [gdArea.lt-xl],  [gdArea.gt-xs], [gdArea.gt-sm], [gdArea.gt-md], [gdArea.gt-lg]", never, {
    "gdArea": {
      "alias": "gdArea";
      "required": false;
    };
    "gdArea.xs": {
      "alias": "gdArea.xs";
      "required": false;
    };
    "gdArea.sm": {
      "alias": "gdArea.sm";
      "required": false;
    };
    "gdArea.md": {
      "alias": "gdArea.md";
      "required": false;
    };
    "gdArea.lg": {
      "alias": "gdArea.lg";
      "required": false;
    };
    "gdArea.xl": {
      "alias": "gdArea.xl";
      "required": false;
    };
    "gdArea.lt-sm": {
      "alias": "gdArea.lt-sm";
      "required": false;
    };
    "gdArea.lt-md": {
      "alias": "gdArea.lt-md";
      "required": false;
    };
    "gdArea.lt-lg": {
      "alias": "gdArea.lt-lg";
      "required": false;
    };
    "gdArea.lt-xl": {
      "alias": "gdArea.lt-xl";
      "required": false;
    };
    "gdArea.gt-xs": {
      "alias": "gdArea.gt-xs";
      "required": false;
    };
    "gdArea.gt-sm": {
      "alias": "gdArea.gt-sm";
      "required": false;
    };
    "gdArea.gt-md": {
      "alias": "gdArea.gt-md";
      "required": false;
    };
    "gdArea.gt-lg": {
      "alias": "gdArea.gt-lg";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
export interface GridAreasParent {
  inline: boolean;
}
export declare class GridAreasStyleBuiler extends StyleBuilder {
  buildStyles(input: string, parent: GridAreasParent): {
    display: string;
    'grid-template-areas': string;
  };
  static ɵfac: i0.ɵɵFactoryDeclaration<GridAreasStyleBuiler, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare class GridAreasDirective extends BaseDirective2 {
  protected DIRECTIVE_KEY: string;
  get inline(): boolean;
  set inline(val: BooleanInput);
  protected _inline: boolean;
  constructor(elRef: ElementRef, styleUtils: StyleUtils, styleBuilder: GridAreasStyleBuiler, marshal: MediaMarshaller);
  protected updateWithValue(value: string): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<GridAreasDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<GridAreasDirective, never, never, {
    "inline": {
      "alias": "gdInline";
      "required": false;
    };
  }, {}, never, never, true, never>;
}
/**
 * 'grid-template-areas' CSS Grid styling directive
 * Configures the names of elements within the grid
 * @see https://css-tricks.com/snippets/css/complete-guide-grid/#article-header-id-14
 */
export declare class DefaultGridAreasDirective extends GridAreasDirective {
  protected inputs: string[];
  static ɵfac: i0.ɵɵFactoryDeclaration<DefaultGridAreasDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DefaultGridAreasDirective, "  [gdAreas],  [gdAreas.xs], [gdAreas.sm], [gdAreas.md], [gdAreas.lg], [gdAreas.xl],  [gdAreas.lt-sm], [gdAreas.lt-md], [gdAreas.lt-lg], [gdAreas.lt-xl],  [gdAreas.gt-xs], [gdAreas.gt-sm], [gdAreas.gt-md], [gdAreas.gt-lg]", never, {
    "gdAreas": {
      "alias": "gdAreas";
      "required": false;
    };
    "gdAreas.xs": {
      "alias": "gdAreas.xs";
      "required": false;
    };
    "gdAreas.sm": {
      "alias": "gdAreas.sm";
      "required": false;
    };
    "gdAreas.md": {
      "alias": "gdAreas.md";
      "required": false;
    };
    "gdAreas.lg": {
      "alias": "gdAreas.lg";
      "required": false;
    };
    "gdAreas.xl": {
      "alias": "gdAreas.xl";
      "required": false;
    };
    "gdAreas.lt-sm": {
      "alias": "gdAreas.lt-sm";
      "required": false;
    };
    "gdAreas.lt-md": {
      "alias": "gdAreas.lt-md";
      "required": false;
    };
    "gdAreas.lt-lg": {
      "alias": "gdAreas.lt-lg";
      "required": false;
    };
    "gdAreas.lt-xl": {
      "alias": "gdAreas.lt-xl";
      "required": false;
    };
    "gdAreas.gt-xs": {
      "alias": "gdAreas.gt-xs";
      "required": false;
    };
    "gdAreas.gt-sm": {
      "alias": "gdAreas.gt-sm";
      "required": false;
    };
    "gdAreas.gt-md": {
      "alias": "gdAreas.gt-md";
      "required": false;
    };
    "gdAreas.gt-lg": {
      "alias": "gdAreas.gt-lg";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
export interface GridAutoParent {
  inline: boolean;
}
export declare class GridAutoStyleBuilder extends StyleBuilder {
  buildStyles(input: string, parent: GridAutoParent): {
    display: string;
    'grid-auto-flow': string;
  };
  static ɵfac: i0.ɵɵFactoryDeclaration<GridAutoStyleBuilder, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare class GridAutoDirective extends BaseDirective2 {
  get inline(): boolean;
  set inline(val: BooleanInput);
  protected _inline: boolean;
  protected DIRECTIVE_KEY: string;
  constructor(elementRef: ElementRef, styleBuilder: GridAutoStyleBuilder, styler: StyleUtils, marshal: MediaMarshaller);
  protected updateWithValue(value: string): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<GridAutoDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<GridAutoDirective, never, never, {
    "inline": {
      "alias": "gdInline";
      "required": false;
    };
  }, {}, never, never, true, never>;
}
/**
 * 'grid-auto-flow' CSS Grid styling directive
 * Configures the auto placement algorithm for the grid
 * @see https://css-tricks.com/snippets/css/complete-guide-grid/#article-header-id-23
 */
export declare class DefaultGridAutoDirective extends GridAutoDirective {
  protected inputs: string[];
  static ɵfac: i0.ɵɵFactoryDeclaration<DefaultGridAutoDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DefaultGridAutoDirective, "  [gdAuto],  [gdAuto.xs], [gdAuto.sm], [gdAuto.md], [gdAuto.lg], [gdAuto.xl],  [gdAuto.lt-sm], [gdAuto.lt-md], [gdAuto.lt-lg], [gdAuto.lt-xl],  [gdAuto.gt-xs], [gdAuto.gt-sm], [gdAuto.gt-md], [gdAuto.gt-lg]", never, {
    "gdAuto": {
      "alias": "gdAuto";
      "required": false;
    };
    "gdAuto.xs": {
      "alias": "gdAuto.xs";
      "required": false;
    };
    "gdAuto.sm": {
      "alias": "gdAuto.sm";
      "required": false;
    };
    "gdAuto.md": {
      "alias": "gdAuto.md";
      "required": false;
    };
    "gdAuto.lg": {
      "alias": "gdAuto.lg";
      "required": false;
    };
    "gdAuto.xl": {
      "alias": "gdAuto.xl";
      "required": false;
    };
    "gdAuto.lt-sm": {
      "alias": "gdAuto.lt-sm";
      "required": false;
    };
    "gdAuto.lt-md": {
      "alias": "gdAuto.lt-md";
      "required": false;
    };
    "gdAuto.lt-lg": {
      "alias": "gdAuto.lt-lg";
      "required": false;
    };
    "gdAuto.lt-xl": {
      "alias": "gdAuto.lt-xl";
      "required": false;
    };
    "gdAuto.gt-xs": {
      "alias": "gdAuto.gt-xs";
      "required": false;
    };
    "gdAuto.gt-sm": {
      "alias": "gdAuto.gt-sm";
      "required": false;
    };
    "gdAuto.gt-md": {
      "alias": "gdAuto.gt-md";
      "required": false;
    };
    "gdAuto.gt-lg": {
      "alias": "gdAuto.gt-lg";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
export declare class GridColumnStyleBuilder extends StyleBuilder {
  buildStyles(input: string): {
    'grid-column': string;
  };
  static ɵfac: i0.ɵɵFactoryDeclaration<GridColumnStyleBuilder, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare class GridColumnDirective extends BaseDirective2 {
  protected DIRECTIVE_KEY: string;
  constructor(elementRef: ElementRef, styleBuilder: GridColumnStyleBuilder, styler: StyleUtils, marshal: MediaMarshaller);
  protected styleCache: Map<string, StyleDefinition>;
  static ɵfac: i0.ɵɵFactoryDeclaration<GridColumnDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<GridColumnDirective, never, never, {}, {}, never, never, true, never>;
}
/**
 * 'grid-column' CSS Grid styling directive
 * Configures the name or position of an element within the grid
 * @see https://css-tricks.com/snippets/css/complete-guide-grid/#article-header-id-26
 */
export declare class DefaultGridColumnDirective extends GridColumnDirective {
  protected inputs: string[];
  static ɵfac: i0.ɵɵFactoryDeclaration<DefaultGridColumnDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DefaultGridColumnDirective, "  [gdColumn],  [gdColumn.xs], [gdColumn.sm], [gdColumn.md], [gdColumn.lg], [gdColumn.xl],  [gdColumn.lt-sm], [gdColumn.lt-md], [gdColumn.lt-lg], [gdColumn.lt-xl],  [gdColumn.gt-xs], [gdColumn.gt-sm], [gdColumn.gt-md], [gdColumn.gt-lg]", never, {
    "gdColumn": {
      "alias": "gdColumn";
      "required": false;
    };
    "gdColumn.xs": {
      "alias": "gdColumn.xs";
      "required": false;
    };
    "gdColumn.sm": {
      "alias": "gdColumn.sm";
      "required": false;
    };
    "gdColumn.md": {
      "alias": "gdColumn.md";
      "required": false;
    };
    "gdColumn.lg": {
      "alias": "gdColumn.lg";
      "required": false;
    };
    "gdColumn.xl": {
      "alias": "gdColumn.xl";
      "required": false;
    };
    "gdColumn.lt-sm": {
      "alias": "gdColumn.lt-sm";
      "required": false;
    };
    "gdColumn.lt-md": {
      "alias": "gdColumn.lt-md";
      "required": false;
    };
    "gdColumn.lt-lg": {
      "alias": "gdColumn.lt-lg";
      "required": false;
    };
    "gdColumn.lt-xl": {
      "alias": "gdColumn.lt-xl";
      "required": false;
    };
    "gdColumn.gt-xs": {
      "alias": "gdColumn.gt-xs";
      "required": false;
    };
    "gdColumn.gt-sm": {
      "alias": "gdColumn.gt-sm";
      "required": false;
    };
    "gdColumn.gt-md": {
      "alias": "gdColumn.gt-md";
      "required": false;
    };
    "gdColumn.gt-lg": {
      "alias": "gdColumn.gt-lg";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
export interface GridColumnsParent {
  inline: boolean;
}
export declare class GridColumnsStyleBuilder extends StyleBuilder {
  buildStyles(input: string, parent: GridColumnsParent): {
    display: string;
    'grid-auto-columns': string;
    'grid-template-columns': string;
  };
  static ɵfac: i0.ɵɵFactoryDeclaration<GridColumnsStyleBuilder, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare class GridColumnsDirective extends BaseDirective2 {
  protected DIRECTIVE_KEY: string;
  get inline(): boolean;
  set inline(val: BooleanInput);
  protected _inline: boolean;
  constructor(elementRef: ElementRef, styleBuilder: GridColumnsStyleBuilder, styler: StyleUtils, marshal: MediaMarshaller);
  protected updateWithValue(value: string): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<GridColumnsDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<GridColumnsDirective, never, never, {
    "inline": {
      "alias": "gdInline";
      "required": false;
    };
  }, {}, never, never, true, never>;
}
/**
 * 'grid-template-columns' CSS Grid styling directive
 * Configures the sizing for the columns in the grid
 * Syntax: <column value> [auto]
 * @see https://css-tricks.com/snippets/css/complete-guide-grid/#article-header-id-13
 */
export declare class DefaultGridColumnsDirective extends GridColumnsDirective {
  protected inputs: string[];
  static ɵfac: i0.ɵɵFactoryDeclaration<DefaultGridColumnsDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DefaultGridColumnsDirective, "  [gdColumns],  [gdColumns.xs], [gdColumns.sm], [gdColumns.md], [gdColumns.lg], [gdColumns.xl],  [gdColumns.lt-sm], [gdColumns.lt-md], [gdColumns.lt-lg], [gdColumns.lt-xl],  [gdColumns.gt-xs], [gdColumns.gt-sm], [gdColumns.gt-md], [gdColumns.gt-lg]", never, {
    "gdColumns": {
      "alias": "gdColumns";
      "required": false;
    };
    "gdColumns.xs": {
      "alias": "gdColumns.xs";
      "required": false;
    };
    "gdColumns.sm": {
      "alias": "gdColumns.sm";
      "required": false;
    };
    "gdColumns.md": {
      "alias": "gdColumns.md";
      "required": false;
    };
    "gdColumns.lg": {
      "alias": "gdColumns.lg";
      "required": false;
    };
    "gdColumns.xl": {
      "alias": "gdColumns.xl";
      "required": false;
    };
    "gdColumns.lt-sm": {
      "alias": "gdColumns.lt-sm";
      "required": false;
    };
    "gdColumns.lt-md": {
      "alias": "gdColumns.lt-md";
      "required": false;
    };
    "gdColumns.lt-lg": {
      "alias": "gdColumns.lt-lg";
      "required": false;
    };
    "gdColumns.lt-xl": {
      "alias": "gdColumns.lt-xl";
      "required": false;
    };
    "gdColumns.gt-xs": {
      "alias": "gdColumns.gt-xs";
      "required": false;
    };
    "gdColumns.gt-sm": {
      "alias": "gdColumns.gt-sm";
      "required": false;
    };
    "gdColumns.gt-md": {
      "alias": "gdColumns.gt-md";
      "required": false;
    };
    "gdColumns.gt-lg": {
      "alias": "gdColumns.gt-lg";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
export interface GridGapParent {
  inline: boolean;
}
export declare class GridGapStyleBuilder extends StyleBuilder {
  buildStyles(input: string, parent: GridGapParent): {
    display: string;
    'grid-gap': string;
  };
  static ɵfac: i0.ɵɵFactoryDeclaration<GridGapStyleBuilder, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare class GridGapDirective extends BaseDirective2 {
  protected DIRECTIVE_KEY: string;
  get inline(): boolean;
  set inline(val: BooleanInput);
  protected _inline: boolean;
  constructor(elRef: ElementRef, styleUtils: StyleUtils, styleBuilder: GridGapStyleBuilder, marshal: MediaMarshaller);
  protected updateWithValue(value: string): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<GridGapDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<GridGapDirective, never, never, {
    "inline": {
      "alias": "gdInline";
      "required": false;
    };
  }, {}, never, never, true, never>;
}
/**
 * 'grid-gap' CSS Grid styling directive
 * Configures the gap between items in the grid
 * Syntax: <row gap> [<column-gap>]
 * @see https://css-tricks.com/snippets/css/complete-guide-grid/#article-header-id-17
 */
export declare class DefaultGridGapDirective extends GridGapDirective {
  protected inputs: string[];
  static ɵfac: i0.ɵɵFactoryDeclaration<DefaultGridGapDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DefaultGridGapDirective, "  [gdGap],  [gdGap.xs], [gdGap.sm], [gdGap.md], [gdGap.lg], [gdGap.xl],  [gdGap.lt-sm], [gdGap.lt-md], [gdGap.lt-lg], [gdGap.lt-xl],  [gdGap.gt-xs], [gdGap.gt-sm], [gdGap.gt-md], [gdGap.gt-lg]", never, {
    "gdGap": {
      "alias": "gdGap";
      "required": false;
    };
    "gdGap.xs": {
      "alias": "gdGap.xs";
      "required": false;
    };
    "gdGap.sm": {
      "alias": "gdGap.sm";
      "required": false;
    };
    "gdGap.md": {
      "alias": "gdGap.md";
      "required": false;
    };
    "gdGap.lg": {
      "alias": "gdGap.lg";
      "required": false;
    };
    "gdGap.xl": {
      "alias": "gdGap.xl";
      "required": false;
    };
    "gdGap.lt-sm": {
      "alias": "gdGap.lt-sm";
      "required": false;
    };
    "gdGap.lt-md": {
      "alias": "gdGap.lt-md";
      "required": false;
    };
    "gdGap.lt-lg": {
      "alias": "gdGap.lt-lg";
      "required": false;
    };
    "gdGap.lt-xl": {
      "alias": "gdGap.lt-xl";
      "required": false;
    };
    "gdGap.gt-xs": {
      "alias": "gdGap.gt-xs";
      "required": false;
    };
    "gdGap.gt-sm": {
      "alias": "gdGap.gt-sm";
      "required": false;
    };
    "gdGap.gt-md": {
      "alias": "gdGap.gt-md";
      "required": false;
    };
    "gdGap.gt-lg": {
      "alias": "gdGap.gt-lg";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
export declare class GridRowStyleBuilder extends StyleBuilder {
  buildStyles(input: string): {
    'grid-row': string;
  };
  static ɵfac: i0.ɵɵFactoryDeclaration<GridRowStyleBuilder, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare class GridRowDirective extends BaseDirective2 {
  protected DIRECTIVE_KEY: string;
  constructor(elementRef: ElementRef, styleBuilder: GridRowStyleBuilder, styler: StyleUtils, marshal: MediaMarshaller);
  protected styleCache: Map<string, StyleDefinition>;
  static ɵfac: i0.ɵɵFactoryDeclaration<GridRowDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<GridRowDirective, never, never, {}, {}, never, never, true, never>;
}
/**
 * 'grid-row' CSS Grid styling directive
 * Configures the name or position of an element within the grid
 * @see https://css-tricks.com/snippets/css/complete-guide-grid/#article-header-id-26
 */
export declare class DefaultGridRowDirective extends GridRowDirective {
  protected inputs: string[];
  static ɵfac: i0.ɵɵFactoryDeclaration<DefaultGridRowDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DefaultGridRowDirective, "  [gdRow],  [gdRow.xs], [gdRow.sm], [gdRow.md], [gdRow.lg], [gdRow.xl],  [gdRow.lt-sm], [gdRow.lt-md], [gdRow.lt-lg], [gdRow.lt-xl],  [gdRow.gt-xs], [gdRow.gt-sm], [gdRow.gt-md], [gdRow.gt-lg]", never, {
    "gdRow": {
      "alias": "gdRow";
      "required": false;
    };
    "gdRow.xs": {
      "alias": "gdRow.xs";
      "required": false;
    };
    "gdRow.sm": {
      "alias": "gdRow.sm";
      "required": false;
    };
    "gdRow.md": {
      "alias": "gdRow.md";
      "required": false;
    };
    "gdRow.lg": {
      "alias": "gdRow.lg";
      "required": false;
    };
    "gdRow.xl": {
      "alias": "gdRow.xl";
      "required": false;
    };
    "gdRow.lt-sm": {
      "alias": "gdRow.lt-sm";
      "required": false;
    };
    "gdRow.lt-md": {
      "alias": "gdRow.lt-md";
      "required": false;
    };
    "gdRow.lt-lg": {
      "alias": "gdRow.lt-lg";
      "required": false;
    };
    "gdRow.lt-xl": {
      "alias": "gdRow.lt-xl";
      "required": false;
    };
    "gdRow.gt-xs": {
      "alias": "gdRow.gt-xs";
      "required": false;
    };
    "gdRow.gt-sm": {
      "alias": "gdRow.gt-sm";
      "required": false;
    };
    "gdRow.gt-md": {
      "alias": "gdRow.gt-md";
      "required": false;
    };
    "gdRow.gt-lg": {
      "alias": "gdRow.gt-lg";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
export interface GridRowsParent {
  inline: boolean;
}
export declare class GridRowsStyleBuilder extends StyleBuilder {
  buildStyles(input: string, parent: GridRowsParent): {
    display: string;
    'grid-auto-rows': string;
    'grid-template-rows': string;
  };
  static ɵfac: i0.ɵɵFactoryDeclaration<GridRowsStyleBuilder, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare class GridRowsDirective extends BaseDirective2 {
  protected DIRECTIVE_KEY: string;
  get inline(): boolean;
  set inline(val: BooleanInput);
  protected _inline: boolean;
  constructor(elementRef: ElementRef, styleBuilder: GridRowsStyleBuilder, styler: StyleUtils, marshal: MediaMarshaller);
  protected updateWithValue(value: string): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<GridRowsDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<GridRowsDirective, never, never, {
    "inline": {
      "alias": "gdInline";
      "required": false;
    };
  }, {}, never, never, true, never>;
}
/**
 * 'grid-template-rows' CSS Grid styling directive
 * Configures the sizing for the rows in the grid
 * Syntax: <column value> [auto]
 * @see https://css-tricks.com/snippets/css/complete-guide-grid/#article-header-id-13
 */
export declare class DefaultGridRowsDirective extends GridRowsDirective {
  protected inputs: string[];
  static ɵfac: i0.ɵɵFactoryDeclaration<DefaultGridRowsDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DefaultGridRowsDirective, "  [gdRows],  [gdRows.xs], [gdRows.sm], [gdRows.md], [gdRows.lg], [gdRows.xl],  [gdRows.lt-sm], [gdRows.lt-md], [gdRows.lt-lg], [gdRows.lt-xl],  [gdRows.gt-xs], [gdRows.gt-sm], [gdRows.gt-md], [gdRows.gt-lg]", never, {
    "gdRows": {
      "alias": "gdRows";
      "required": false;
    };
    "gdRows.xs": {
      "alias": "gdRows.xs";
      "required": false;
    };
    "gdRows.sm": {
      "alias": "gdRows.sm";
      "required": false;
    };
    "gdRows.md": {
      "alias": "gdRows.md";
      "required": false;
    };
    "gdRows.lg": {
      "alias": "gdRows.lg";
      "required": false;
    };
    "gdRows.xl": {
      "alias": "gdRows.xl";
      "required": false;
    };
    "gdRows.lt-sm": {
      "alias": "gdRows.lt-sm";
      "required": false;
    };
    "gdRows.lt-md": {
      "alias": "gdRows.lt-md";
      "required": false;
    };
    "gdRows.lt-lg": {
      "alias": "gdRows.lt-lg";
      "required": false;
    };
    "gdRows.lt-xl": {
      "alias": "gdRows.lt-xl";
      "required": false;
    };
    "gdRows.gt-xs": {
      "alias": "gdRows.gt-xs";
      "required": false;
    };
    "gdRows.gt-sm": {
      "alias": "gdRows.gt-sm";
      "required": false;
    };
    "gdRows.gt-md": {
      "alias": "gdRows.gt-md";
      "required": false;
    };
    "gdRows.gt-lg": {
      "alias": "gdRows.gt-lg";
      "required": false;
    };
  }, {}, never, never, false, never>;
}
/**
 * *****************************************************************
 * Define module for the CSS Grid API
 * *****************************************************************
 */
export declare class GridModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<GridModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<GridModule, [typeof DefaultGridAlignDirective, typeof DefaultGridAlignColumnsDirective, typeof DefaultGridAlignRowsDirective, typeof DefaultGridAreaDirective, typeof DefaultGridAreasDirective, typeof DefaultGridAutoDirective, typeof DefaultGridColumnDirective, typeof DefaultGridColumnsDirective, typeof DefaultGridGapDirective, typeof DefaultGridRowDirective, typeof DefaultGridRowsDirective], [typeof i12.CoreModule], [typeof DefaultGridAlignDirective, typeof DefaultGridAlignColumnsDirective, typeof DefaultGridAlignRowsDirective, typeof DefaultGridAreaDirective, typeof DefaultGridAreasDirective, typeof DefaultGridAutoDirective, typeof DefaultGridColumnDirective, typeof DefaultGridColumnsDirective, typeof DefaultGridGapDirective, typeof DefaultGridRowDirective, typeof DefaultGridRowsDirective]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<GridModule>;
}
//# sourceMappingURL=angular-flex-layout-grid.d.ts.map