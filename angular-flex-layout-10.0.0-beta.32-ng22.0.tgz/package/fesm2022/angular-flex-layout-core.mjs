import * as i0 from "@angular/core";
import { APP_BOOTSTRAP_LISTENER, Directive, Inject, Injectable, InjectionToken, NgModule, PLATFORM_ID, inject } from "@angular/core";
import { DOCUMENT, isPlatformBrowser, isPlatformServer } from "@angular/common";
import { BehaviorSubject, Observable, Subject, asapScheduler, fromEvent, merge, of } from "rxjs";
import { applyCssPrefixes, buildLayoutCSS, extendObject } from "@angular/flex-layout/_private-utils";
import { debounceTime, filter, map, switchMap, take, takeUntil, tap } from "rxjs/operators";
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
function removeStyles(_document, platformId) {
	return () => {
		if (isPlatformBrowser(platformId)) {
			const elements = Array.from(_document.querySelectorAll(`[class*=${CLASS_NAME}]`));
			const classRegex = /\bflex-layout-.+?\b/g;
			elements.forEach((el) => {
				el.classList.contains(`flex-layout-ssr`) && el.parentNode ? el.parentNode.removeChild(el) : el.className.replace(classRegex, "");
			});
		}
	};
}
const BROWSER_PROVIDER = {
	provide: APP_BOOTSTRAP_LISTENER,
	useFactory: removeStyles,
	deps: [DOCUMENT, PLATFORM_ID],
	multi: true
};
const CLASS_NAME = "flex-layout-";
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
var CoreModule = class CoreModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: CoreModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: CoreModule
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: CoreModule,
			providers: [BROWSER_PROVIDER]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CoreModule,
	decorators: [{
		type: NgModule,
		args: [{ providers: [BROWSER_PROVIDER] }]
	}]
});
var MediaChange = class MediaChange {
	constructor(matches = false, mediaQuery = "all", mqAlias = "", suffix = "", priority = 0) {
		this.matches = matches;
		this.mediaQuery = mediaQuery;
		this.mqAlias = mqAlias;
		this.suffix = suffix;
		this.priority = priority;
		this.property = "";
	}
	clone() {
		return new MediaChange(this.matches, this.mediaQuery, this.mqAlias, this.suffix);
	}
};
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
var StylesheetMap = class StylesheetMap {
	constructor() {
		this.stylesheet = /* @__PURE__ */ new Map();
	}
	addStyleToElement(element, style, value) {
		const stylesheet = this.stylesheet.get(element);
		if (stylesheet) stylesheet.set(style, value);
		else this.stylesheet.set(element, /* @__PURE__ */ new Map([[style, value]]));
	}
	clearStyles() {
		this.stylesheet.clear();
	}
	getStyleForElement(el, styleName) {
		const styles = this.stylesheet.get(el);
		let value = "";
		if (styles) {
			const style = styles.get(styleName);
			if (typeof style === "number" || typeof style === "string") value = style + "";
		}
		return value;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: StylesheetMap,
			deps: [],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: StylesheetMap,
			providedIn: "root"
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: StylesheetMap,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
const DEFAULT_CONFIG = {
	addFlexToParent: true,
	addOrientationBps: false,
	disableDefaultBps: false,
	disableVendorPrefixes: false,
	serverLoaded: false,
	useColumnBasisZero: true,
	printWithBreakpoints: [],
	mediaTriggerAutoRestore: true,
	ssrObserveBreakpoints: []
};
const LAYOUT_CONFIG = new InjectionToken("Flex Layout token, config options for the library", {
	providedIn: "root",
	factory: () => DEFAULT_CONFIG
});
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
const SERVER_TOKEN = new InjectionToken("FlexLayoutServerLoaded", {
	providedIn: "root",
	factory: () => false
});
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
const BREAKPOINT = new InjectionToken("Flex Layout token, collect all breakpoints into one provider", {
	providedIn: "root",
	factory: () => null
});
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
function mergeAlias(dest, source) {
	dest = dest ? dest.clone() : new MediaChange();
	if (source) {
		dest.mqAlias = source.alias;
		dest.mediaQuery = source.mediaQuery;
		dest.suffix = source.suffix;
		dest.priority = source.priority;
	}
	return dest;
}
var StyleBuilder = class {
	constructor() {
		this.shouldCache = true;
	}
	sideEffect(_input, _styles, _parent) {}
};
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
var StyleUtils = class StyleUtils {
	constructor(_serverStylesheet, _serverModuleLoaded, _platformId, layoutConfig) {
		this._serverStylesheet = _serverStylesheet;
		this._serverModuleLoaded = _serverModuleLoaded;
		this._platformId = _platformId;
		this.layoutConfig = layoutConfig;
	}
	applyStyleToElement(element, style, value = null) {
		let styles = {};
		if (typeof style === "string") {
			styles[style] = value;
			style = styles;
		}
		styles = this.layoutConfig.disableVendorPrefixes ? style : applyCssPrefixes(style);
		this._applyMultiValueStyleToElement(styles, element);
	}
	applyStyleToElements(style, elements = []) {
		const styles = this.layoutConfig.disableVendorPrefixes ? style : applyCssPrefixes(style);
		elements.forEach((el) => {
			this._applyMultiValueStyleToElement(styles, el);
		});
	}
	getFlowDirection(target) {
		const query = "flex-direction";
		let value = this.lookupStyle(target, query);
		const hasInlineValue = this.lookupInlineStyle(target, query) || isPlatformServer(this._platformId) && this._serverModuleLoaded ? value : "";
		return [value || "row", hasInlineValue];
	}
	hasWrap(target) {
		return this.lookupStyle(target, "flex-wrap") === "wrap";
	}
	lookupAttributeValue(element, attribute) {
		return element.getAttribute(attribute) || "";
	}
	lookupInlineStyle(element, styleName) {
		return isPlatformBrowser(this._platformId) ? element.style.getPropertyValue(styleName) : this._getServerStyle(element, styleName);
	}
	lookupStyle(element, styleName, inlineOnly = false) {
		let value = "";
		if (element) {
			if (!(value = this.lookupInlineStyle(element, styleName))) {
				if (isPlatformBrowser(this._platformId)) {
					if (!inlineOnly) value = getComputedStyle(element).getPropertyValue(styleName);
				} else if (this._serverModuleLoaded) value = this._serverStylesheet.getStyleForElement(element, styleName);
			}
		}
		return value ? value.trim() : "";
	}
	_applyMultiValueStyleToElement(styles, element) {
		Object.keys(styles).sort().forEach((key) => {
			const el = styles[key];
			const values = Array.isArray(el) ? el : [el];
			values.sort();
			for (let value of values) {
				value = value ? value + "" : "";
				if (isPlatformBrowser(this._platformId) || !this._serverModuleLoaded) isPlatformBrowser(this._platformId) ? element.style.setProperty(key, value) : this._setServerStyle(element, key, value);
				else this._serverStylesheet.addStyleToElement(element, key, value);
			}
		});
	}
	_setServerStyle(element, styleName, styleValue) {
		styleName = styleName.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase();
		const styleMap = this._readStyleAttribute(element);
		styleMap[styleName] = styleValue || "";
		this._writeStyleAttribute(element, styleMap);
	}
	_getServerStyle(element, styleName) {
		return this._readStyleAttribute(element)[styleName] || "";
	}
	_readStyleAttribute(element) {
		const styleMap = {};
		const styleAttribute = element.getAttribute("style");
		if (styleAttribute) {
			const styleList = styleAttribute.split(/;+/g);
			for (let i = 0; i < styleList.length; i++) {
				const style = styleList[i].trim();
				if (style.length > 0) {
					const colonIndex = style.indexOf(":");
					if (colonIndex === -1) throw new Error(`Invalid CSS style: ${style}`);
					const name = style.substr(0, colonIndex).trim();
					styleMap[name] = style.substr(colonIndex + 1).trim();
				}
			}
		}
		return styleMap;
	}
	_writeStyleAttribute(element, styleMap) {
		let styleAttrValue = "";
		for (const key in styleMap) if (styleMap[key]) styleAttrValue += key + ":" + styleMap[key] + ";";
		element.setAttribute("style", styleAttrValue);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: StyleUtils,
			deps: [
				{ token: StylesheetMap },
				{ token: SERVER_TOKEN },
				{ token: PLATFORM_ID },
				{ token: LAYOUT_CONFIG }
			],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: StyleUtils,
			providedIn: "root"
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: StyleUtils,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => [
		{ type: StylesheetMap },
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [SERVER_TOKEN]
			}]
		},
		{
			type: Object,
			decorators: [{
				type: Inject,
				args: [PLATFORM_ID]
			}]
		},
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [LAYOUT_CONFIG]
			}]
		}
	]
});
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
function sortDescendingPriority(a, b) {
	const priorityA = a ? a.priority || 0 : 0;
	return (b ? b.priority || 0 : 0) - priorityA;
}
function sortAscendingPriority(a, b) {
	return (a.priority || 0) - (b.priority || 0);
}
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
var MatchMedia = class MatchMedia {
	constructor(_zone, _platformId, _document) {
		this._zone = _zone;
		this._platformId = _platformId;
		this._document = _document;
		this.source = new BehaviorSubject(new MediaChange(true));
		this.registry = /* @__PURE__ */ new Map();
		this.pendingRemoveListenerFns = [];
		this._observable$ = this.source.asObservable();
	}
	get activations() {
		const results = [];
		this.registry.forEach((mql, key) => {
			if (mql.matches) results.push(key);
		});
		return results;
	}
	isActive(mediaQuery) {
		const mql = this.registry.get(mediaQuery);
		return !!mql ? mql.matches : this.registerQuery(mediaQuery).some((m) => m.matches);
	}
	observe(mqList, filterOthers = false) {
		if (mqList && mqList.length) {
			const matchMedia$ = this._observable$.pipe(filter((change) => !filterOthers ? true : mqList.indexOf(change.mediaQuery) > -1));
			const registration$ = new Observable((observer) => {
				const matches = this.registerQuery(mqList);
				if (matches.length) {
					const lastChange = matches.pop();
					matches.forEach((e) => {
						observer.next(e);
					});
					this.source.next(lastChange);
				}
				observer.complete();
			});
			return merge(registration$, matchMedia$);
		}
		return this._observable$;
	}
	registerQuery(mediaQuery) {
		const list = Array.isArray(mediaQuery) ? mediaQuery : [mediaQuery];
		const matches = [];
		buildQueryCss(list, this._document);
		list.forEach((query) => {
			const onMQLEvent = (e) => {
				this._zone.run(() => this.source.next(new MediaChange(e.matches, query)));
			};
			let mql = this.registry.get(query);
			if (!mql) {
				mql = this.buildMQL(query);
				mql.addListener(onMQLEvent);
				this.pendingRemoveListenerFns.push(() => mql.removeListener(onMQLEvent));
				this.registry.set(query, mql);
			}
			if (mql.matches) matches.push(new MediaChange(true, query));
		});
		return matches;
	}
	ngOnDestroy() {
		let fn;
		while (fn = this.pendingRemoveListenerFns.pop()) fn();
	}
	buildMQL(query) {
		return constructMql(query, isPlatformBrowser(this._platformId));
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MatchMedia,
			deps: [
				{ token: i0.NgZone },
				{ token: PLATFORM_ID },
				{ token: DOCUMENT }
			],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MatchMedia,
			providedIn: "root"
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MatchMedia,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => [
		{ type: i0.NgZone },
		{
			type: Object,
			decorators: [{
				type: Inject,
				args: [PLATFORM_ID]
			}]
		},
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [DOCUMENT]
			}]
		}
	]
});
const ALL_STYLES = {};
function buildQueryCss(mediaQueries, _document) {
	const list = mediaQueries.filter((it) => !ALL_STYLES[it]);
	if (list.length > 0) {
		const query = list.join(", ");
		try {
			const styleEl = _document.createElement("style");
			styleEl.setAttribute("type", "text/css");
			if (!styleEl.styleSheet) {
				const cssText = `
/*
  @angular/flex-layout - workaround for possible browser quirk with mediaQuery listeners
  see http://bit.ly/2sd4HMP
*/
@media ${query} {.fx-query-test{ }}
`;
				styleEl.appendChild(_document.createTextNode(cssText));
			}
			_document.head.appendChild(styleEl);
			list.forEach((mq) => ALL_STYLES[mq] = styleEl);
		} catch (e) {
			console.error(e);
		}
	}
}
function constructMql(query, isBrowser) {
	return isBrowser && !!window.matchMedia("all").addListener ? window.matchMedia(query) : {
		matches: query === "all" || query === "",
		media: query,
		addListener: () => {},
		removeListener: () => {},
		onchange: null,
		addEventListener() {},
		removeEventListener() {},
		dispatchEvent() {
			return false;
		}
	};
}
const DEFAULT_BREAKPOINTS = [
	{
		alias: "xs",
		mediaQuery: "screen and (min-width: 0px) and (max-width: 599.9px)",
		priority: 1e3
	},
	{
		alias: "sm",
		mediaQuery: "screen and (min-width: 600px) and (max-width: 959.9px)",
		priority: 900
	},
	{
		alias: "md",
		mediaQuery: "screen and (min-width: 960px) and (max-width: 1279.9px)",
		priority: 800
	},
	{
		alias: "lg",
		mediaQuery: "screen and (min-width: 1280px) and (max-width: 1919.9px)",
		priority: 700
	},
	{
		alias: "xl",
		mediaQuery: "screen and (min-width: 1920px) and (max-width: 4999.9px)",
		priority: 600
	},
	{
		alias: "lt-sm",
		overlapping: true,
		mediaQuery: "screen and (max-width: 599.9px)",
		priority: 950
	},
	{
		alias: "lt-md",
		overlapping: true,
		mediaQuery: "screen and (max-width: 959.9px)",
		priority: 850
	},
	{
		alias: "lt-lg",
		overlapping: true,
		mediaQuery: "screen and (max-width: 1279.9px)",
		priority: 750
	},
	{
		alias: "lt-xl",
		overlapping: true,
		priority: 650,
		mediaQuery: "screen and (max-width: 1919.9px)"
	},
	{
		alias: "gt-xs",
		overlapping: true,
		mediaQuery: "screen and (min-width: 600px)",
		priority: -950
	},
	{
		alias: "gt-sm",
		overlapping: true,
		mediaQuery: "screen and (min-width: 960px)",
		priority: -850
	},
	{
		alias: "gt-md",
		overlapping: true,
		mediaQuery: "screen and (min-width: 1280px)",
		priority: -750
	},
	{
		alias: "gt-lg",
		overlapping: true,
		mediaQuery: "screen and (min-width: 1920px)",
		priority: -650
	}
];
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
const HANDSET_PORTRAIT = "(orientation: portrait) and (max-width: 599.9px)";
const HANDSET_LANDSCAPE = "(orientation: landscape) and (max-width: 959.9px)";
const TABLET_PORTRAIT = "(orientation: portrait) and (min-width: 600px) and (max-width: 839.9px)";
const TABLET_LANDSCAPE = "(orientation: landscape) and (min-width: 960px) and (max-width: 1279.9px)";
const WEB_PORTRAIT = "(orientation: portrait) and (min-width: 840px)";
const WEB_LANDSCAPE = "(orientation: landscape) and (min-width: 1280px)";
const ScreenTypes = {
	"HANDSET": `${HANDSET_PORTRAIT}, ${HANDSET_LANDSCAPE}`,
	"TABLET": `${TABLET_PORTRAIT} , ${TABLET_LANDSCAPE}`,
	"WEB": `${WEB_PORTRAIT}, ${WEB_LANDSCAPE} `,
	"HANDSET_PORTRAIT": `${HANDSET_PORTRAIT}`,
	"TABLET_PORTRAIT": `${TABLET_PORTRAIT} `,
	"WEB_PORTRAIT": `${WEB_PORTRAIT}`,
	"HANDSET_LANDSCAPE": `${HANDSET_LANDSCAPE}`,
	"TABLET_LANDSCAPE": `${TABLET_LANDSCAPE}`,
	"WEB_LANDSCAPE": `${WEB_LANDSCAPE}`
};
const ORIENTATION_BREAKPOINTS = [
	{
		"alias": "handset",
		priority: 2e3,
		"mediaQuery": ScreenTypes.HANDSET
	},
	{
		"alias": "handset.landscape",
		priority: 2e3,
		"mediaQuery": ScreenTypes.HANDSET_LANDSCAPE
	},
	{
		"alias": "handset.portrait",
		priority: 2e3,
		"mediaQuery": ScreenTypes.HANDSET_PORTRAIT
	},
	{
		"alias": "tablet",
		priority: 2100,
		"mediaQuery": ScreenTypes.TABLET
	},
	{
		"alias": "tablet.landscape",
		priority: 2100,
		"mediaQuery": ScreenTypes.TABLET_LANDSCAPE
	},
	{
		"alias": "tablet.portrait",
		priority: 2100,
		"mediaQuery": ScreenTypes.TABLET_PORTRAIT
	},
	{
		"alias": "web",
		priority: 2200,
		"mediaQuery": ScreenTypes.WEB,
		overlapping: true
	},
	{
		"alias": "web.landscape",
		priority: 2200,
		"mediaQuery": ScreenTypes.WEB_LANDSCAPE,
		overlapping: true
	},
	{
		"alias": "web.portrait",
		priority: 2200,
		"mediaQuery": ScreenTypes.WEB_PORTRAIT,
		overlapping: true
	}
];
const ALIAS_DELIMITERS = /(\.|-|_)/g;
function firstUpperCase(part) {
	let first = part.length > 0 ? part.charAt(0) : "";
	let remainder = part.length > 1 ? part.slice(1) : "";
	return first.toUpperCase() + remainder;
}
function camelCase(name) {
	return name.replace(ALIAS_DELIMITERS, "|").split("|").map(firstUpperCase).join("");
}
function validateSuffixes(list) {
	list.forEach((bp) => {
		if (!bp.suffix) {
			bp.suffix = camelCase(bp.alias);
			bp.overlapping = !!bp.overlapping;
		}
	});
	return list;
}
function mergeByAlias(defaults, custom = []) {
	const dict = {};
	defaults.forEach((bp) => {
		dict[bp.alias] = bp;
	});
	custom.forEach((bp) => {
		if (dict[bp.alias]) extendObject(dict[bp.alias], bp);
		else dict[bp.alias] = bp;
	});
	return validateSuffixes(Object.keys(dict).map((k) => dict[k]));
}
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
const BREAKPOINTS = new InjectionToken("Token (@angular/flex-layout) Breakpoints", {
	providedIn: "root",
	factory: () => {
		const breakpoints = inject(BREAKPOINT);
		const layoutConfig = inject(LAYOUT_CONFIG);
		const bpFlattenArray = [].concat.apply([], (breakpoints || []).map((v) => Array.isArray(v) ? v : [v]));
		return mergeByAlias((layoutConfig.disableDefaultBps ? [] : DEFAULT_BREAKPOINTS).concat(layoutConfig.addOrientationBps ? ORIENTATION_BREAKPOINTS : []), bpFlattenArray);
	}
});
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
var BreakPointRegistry = class BreakPointRegistry {
	constructor(list) {
		this.findByMap = /* @__PURE__ */ new Map();
		this.items = [...list].sort(sortAscendingPriority);
	}
	findByAlias(alias) {
		return !alias ? null : this.findWithPredicate(alias, (bp) => bp.alias == alias);
	}
	findByQuery(query) {
		return this.findWithPredicate(query, (bp) => bp.mediaQuery == query);
	}
	get overlappings() {
		return this.items.filter((it) => it.overlapping == true);
	}
	get aliases() {
		return this.items.map((it) => it.alias);
	}
	get suffixes() {
		return this.items.map((it) => !!it.suffix ? it.suffix : "");
	}
	findWithPredicate(key, searchFn) {
		let response = this.findByMap.get(key);
		if (!response) {
			response = this.items.find(searchFn) || null;
			this.findByMap.set(key, response);
		}
		return response || null;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: BreakPointRegistry,
			deps: [{ token: BREAKPOINTS }],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: BreakPointRegistry,
			providedIn: "root"
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: BreakPointRegistry,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => [{
		type: void 0,
		decorators: [{
			type: Inject,
			args: [BREAKPOINTS]
		}]
	}]
});
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
const PRINT = "print";
const BREAKPOINT_PRINT = {
	alias: PRINT,
	mediaQuery: PRINT,
	priority: 1e3
};
var PrintHook = class PrintHook {
	constructor(breakpoints, layoutConfig, _document) {
		this.breakpoints = breakpoints;
		this.layoutConfig = layoutConfig;
		this._document = _document;
		this.registeredBeforeAfterPrintHooks = false;
		this.isPrintingBeforeAfterEvent = false;
		this.beforePrintEventListeners = [];
		this.afterPrintEventListeners = [];
		this.isPrinting = false;
		this.queue = new PrintQueue();
		this.deactivations = [];
	}
	withPrintQuery(queries) {
		return [...queries, PRINT];
	}
	isPrintEvent(e) {
		return e.mediaQuery.startsWith(PRINT);
	}
	get printAlias() {
		return this.layoutConfig.printWithBreakpoints || [];
	}
	get printBreakPoints() {
		return this.printAlias.map((alias) => this.breakpoints.findByAlias(alias)).filter((bp) => bp !== null);
	}
	getEventBreakpoints({ mediaQuery }) {
		const bp = this.breakpoints.findByQuery(mediaQuery);
		return (bp ? [...this.printBreakPoints, bp] : this.printBreakPoints).sort(sortDescendingPriority);
	}
	updateEvent(event) {
		let bp = this.breakpoints.findByQuery(event.mediaQuery);
		if (this.isPrintEvent(event)) {
			bp = this.getEventBreakpoints(event)[0];
			event.mediaQuery = bp ? bp.mediaQuery : "";
		}
		return mergeAlias(event, bp);
	}
	registerBeforeAfterPrintHooks(target) {
		if (!this._document.defaultView || this.registeredBeforeAfterPrintHooks) return;
		this.registeredBeforeAfterPrintHooks = true;
		const beforePrintListener = () => {
			if (!this.isPrinting) {
				this.isPrintingBeforeAfterEvent = true;
				this.startPrinting(target, this.getEventBreakpoints(new MediaChange(true, PRINT)));
				target.updateStyles();
			}
		};
		const afterPrintListener = () => {
			this.isPrintingBeforeAfterEvent = false;
			if (this.isPrinting) {
				this.stopPrinting(target);
				target.updateStyles();
			}
		};
		this._document.defaultView.addEventListener("beforeprint", beforePrintListener);
		this._document.defaultView.addEventListener("afterprint", afterPrintListener);
		this.beforePrintEventListeners.push(beforePrintListener);
		this.afterPrintEventListeners.push(afterPrintListener);
	}
	interceptEvents(target) {
		this.registerBeforeAfterPrintHooks(target);
		return (event) => {
			if (this.isPrintEvent(event)) {
				if (event.matches && !this.isPrinting) {
					this.startPrinting(target, this.getEventBreakpoints(event));
					target.updateStyles();
				} else if (!event.matches && this.isPrinting && !this.isPrintingBeforeAfterEvent) {
					this.stopPrinting(target);
					target.updateStyles();
				}
			} else this.collectActivations(event);
		};
	}
	blockPropagation() {
		return (event) => {
			return !(this.isPrinting || this.isPrintEvent(event));
		};
	}
	startPrinting(target, bpList) {
		this.isPrinting = true;
		target.activatedBreakpoints = this.queue.addPrintBreakpoints(bpList);
	}
	stopPrinting(target) {
		target.activatedBreakpoints = this.deactivations;
		this.deactivations = [];
		this.queue.clear();
		this.isPrinting = false;
	}
	collectActivations(event) {
		if (!this.isPrinting || this.isPrintingBeforeAfterEvent) {
			if (!event.matches) {
				const bp = this.breakpoints.findByQuery(event.mediaQuery);
				if (bp) {
					this.deactivations.push(bp);
					this.deactivations.sort(sortDescendingPriority);
				}
			} else if (!this.isPrintingBeforeAfterEvent) this.deactivations = [];
		}
	}
	ngOnDestroy() {
		this.beforePrintEventListeners.forEach((l) => this._document.defaultView.removeEventListener("beforeprint", l));
		this.afterPrintEventListeners.forEach((l) => this._document.defaultView.removeEventListener("afterprint", l));
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: PrintHook,
			deps: [
				{ token: BreakPointRegistry },
				{ token: LAYOUT_CONFIG },
				{ token: DOCUMENT }
			],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: PrintHook,
			providedIn: "root"
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PrintHook,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => [
		{ type: BreakPointRegistry },
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [LAYOUT_CONFIG]
			}]
		},
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [DOCUMENT]
			}]
		}
	]
});
var PrintQueue = class {
	constructor() {
		this.printBreakpoints = [];
	}
	addPrintBreakpoints(bpList) {
		bpList.push(BREAKPOINT_PRINT);
		bpList.sort(sortDescendingPriority);
		bpList.forEach((bp) => this.addBreakpoint(bp));
		return this.printBreakpoints;
	}
	addBreakpoint(bp) {
		if (!!bp) {
			if (this.printBreakpoints.find((it) => it.mediaQuery === bp.mediaQuery) === void 0) this.printBreakpoints = isPrintBreakPoint(bp) ? [bp, ...this.printBreakpoints] : [...this.printBreakpoints, bp];
		}
	}
	clear() {
		this.printBreakpoints = [];
	}
};
function isPrintBreakPoint(bp) {
	return bp ? bp.mediaQuery.startsWith(PRINT) : false;
}
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
var MediaMarshaller = class MediaMarshaller {
	get activatedAlias() {
		return this.activatedBreakpoints[0] ? this.activatedBreakpoints[0].alias : "";
	}
	constructor(matchMedia, breakpoints, hook) {
		this.matchMedia = matchMedia;
		this.breakpoints = breakpoints;
		this.hook = hook;
		this.activatedBreakpoints = [];
		this.elementMap = /* @__PURE__ */ new Map();
		this.elementKeyMap = /* @__PURE__ */ new WeakMap();
		this.watcherMap = /* @__PURE__ */ new WeakMap();
		this.updateMap = /* @__PURE__ */ new WeakMap();
		this.clearMap = /* @__PURE__ */ new WeakMap();
		this.subject = new Subject();
		this.observeActivations();
	}
	onMediaChange(mc) {
		const bp = this.findByQuery(mc.mediaQuery);
		if (bp) {
			mc = mergeAlias(mc, bp);
			if (mc.matches && this.activatedBreakpoints.indexOf(bp) === -1) {
				this.activatedBreakpoints.push(bp);
				this.activatedBreakpoints.sort(sortDescendingPriority);
				this.updateStyles();
			} else if (!mc.matches && this.activatedBreakpoints.indexOf(bp) !== -1) {
				this.activatedBreakpoints.splice(this.activatedBreakpoints.indexOf(bp), 1);
				this.activatedBreakpoints.sort(sortDescendingPriority);
				this.updateStyles();
			}
		}
	}
	init(element, key, updateFn, clearFn, extraTriggers = []) {
		initBuilderMap(this.updateMap, element, key, updateFn);
		initBuilderMap(this.clearMap, element, key, clearFn);
		this.buildElementKeyMap(element, key);
		this.watchExtraTriggers(element, key, extraTriggers);
	}
	getValue(element, key, bp) {
		const bpMap = this.elementMap.get(element);
		if (bpMap) {
			const values = bp !== void 0 ? bpMap.get(bp) : this.getActivatedValues(bpMap, key);
			if (values) return values.get(key);
		}
	}
	hasValue(element, key) {
		const bpMap = this.elementMap.get(element);
		if (bpMap) {
			const values = this.getActivatedValues(bpMap, key);
			if (values) return values.get(key) !== void 0 || false;
		}
		return false;
	}
	setValue(element, key, val, bp) {
		let bpMap = this.elementMap.get(element);
		if (!bpMap) {
			bpMap = (/* @__PURE__ */ new Map()).set(bp, (/* @__PURE__ */ new Map()).set(key, val));
			this.elementMap.set(element, bpMap);
		} else {
			const values = (bpMap.get(bp) || /* @__PURE__ */ new Map()).set(key, val);
			bpMap.set(bp, values);
			this.elementMap.set(element, bpMap);
		}
		const value = this.getValue(element, key);
		if (value !== void 0) this.updateElement(element, key, value);
	}
	trackValue(element, key) {
		return this.subject.asObservable().pipe(filter((v) => v.element === element && v.key === key));
	}
	updateStyles() {
		this.elementMap.forEach((bpMap, el) => {
			const keyMap = new Set(this.elementKeyMap.get(el));
			let valueMap = this.getActivatedValues(bpMap);
			if (valueMap) valueMap.forEach((v, k) => {
				this.updateElement(el, k, v);
				keyMap.delete(k);
			});
			keyMap.forEach((k) => {
				valueMap = this.getActivatedValues(bpMap, k);
				if (valueMap) {
					const value = valueMap.get(k);
					this.updateElement(el, k, value);
				} else this.clearElement(el, k);
			});
		});
	}
	clearElement(element, key) {
		const builders = this.clearMap.get(element);
		if (builders) {
			const clearFn = builders.get(key);
			if (!!clearFn) {
				clearFn();
				this.subject.next({
					element,
					key,
					value: ""
				});
			}
		}
	}
	updateElement(element, key, value) {
		const builders = this.updateMap.get(element);
		if (builders) {
			const updateFn = builders.get(key);
			if (!!updateFn) {
				updateFn(value);
				this.subject.next({
					element,
					key,
					value
				});
			}
		}
	}
	releaseElement(element) {
		const watcherMap = this.watcherMap.get(element);
		if (watcherMap) {
			watcherMap.forEach((s) => s.unsubscribe());
			this.watcherMap.delete(element);
		}
		const elementMap = this.elementMap.get(element);
		if (elementMap) {
			elementMap.forEach((_, s) => elementMap.delete(s));
			this.elementMap.delete(element);
		}
	}
	triggerUpdate(element, key) {
		const bpMap = this.elementMap.get(element);
		if (bpMap) {
			const valueMap = this.getActivatedValues(bpMap, key);
			if (valueMap) {
				if (key) this.updateElement(element, key, valueMap.get(key));
				else valueMap.forEach((v, k) => this.updateElement(element, k, v));
			}
		}
	}
	buildElementKeyMap(element, key) {
		let keyMap = this.elementKeyMap.get(element);
		if (!keyMap) {
			keyMap = /* @__PURE__ */ new Set();
			this.elementKeyMap.set(element, keyMap);
		}
		keyMap.add(key);
	}
	watchExtraTriggers(element, key, triggers) {
		if (triggers && triggers.length) {
			let watchers = this.watcherMap.get(element);
			if (!watchers) {
				watchers = /* @__PURE__ */ new Map();
				this.watcherMap.set(element, watchers);
			}
			if (!watchers.get(key)) {
				const newSubscription = merge(...triggers).subscribe(() => {
					const currentValue = this.getValue(element, key);
					this.updateElement(element, key, currentValue);
				});
				watchers.set(key, newSubscription);
			}
		}
	}
	findByQuery(query) {
		return this.breakpoints.findByQuery(query);
	}
	getActivatedValues(bpMap, key) {
		for (let i = 0; i < this.activatedBreakpoints.length; i++) {
			const activatedBp = this.activatedBreakpoints[i];
			const valueMap = bpMap.get(activatedBp.alias);
			if (valueMap) {
				if (key === void 0 || valueMap.has(key) && valueMap.get(key) != null) return valueMap;
			}
		}
		const lastHope = bpMap.get("");
		return key === void 0 || lastHope && lastHope.has(key) ? lastHope : void 0;
	}
	observeActivations() {
		const target = this;
		const queries = this.breakpoints.items.map((bp) => bp.mediaQuery);
		this.matchMedia.observe(this.hook.withPrintQuery(queries)).pipe(tap(this.hook.interceptEvents(target)), filter(this.hook.blockPropagation())).subscribe(this.onMediaChange.bind(this));
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MediaMarshaller,
			deps: [
				{ token: MatchMedia },
				{ token: BreakPointRegistry },
				{ token: PrintHook }
			],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MediaMarshaller,
			providedIn: "root"
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MediaMarshaller,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => [
		{ type: MatchMedia },
		{ type: BreakPointRegistry },
		{ type: PrintHook }
	]
});
function initBuilderMap(map, element, key, input) {
	if (input !== void 0) {
		let oldMap = map.get(element);
		if (!oldMap) {
			oldMap = /* @__PURE__ */ new Map();
			map.set(element, oldMap);
		}
		oldMap.set(key, input);
	}
}
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
var BaseDirective2 = class BaseDirective2 {
	get parentElement() {
		return this.elementRef.nativeElement.parentElement;
	}
	get nativeElement() {
		return this.elementRef.nativeElement;
	}
	get activatedValue() {
		return this.marshal.getValue(this.nativeElement, this.DIRECTIVE_KEY);
	}
	set activatedValue(value) {
		this.marshal.setValue(this.nativeElement, this.DIRECTIVE_KEY, value, this.marshal.activatedAlias);
	}
	constructor(elementRef, styleBuilder, styler, marshal) {
		this.elementRef = elementRef;
		this.styleBuilder = styleBuilder;
		this.styler = styler;
		this.marshal = marshal;
		this.DIRECTIVE_KEY = "";
		this.inputs = [];
		this.mru = {};
		this.destroySubject = new Subject();
		this.styleCache = /* @__PURE__ */ new Map();
	}
	ngOnChanges(changes) {
		Object.keys(changes).forEach((key) => {
			if (this.inputs.indexOf(key) !== -1) {
				const bp = key.split(".").slice(1).join(".");
				const val = changes[key].currentValue;
				this.setValue(val, bp);
			}
		});
	}
	ngOnDestroy() {
		this.destroySubject.next();
		this.destroySubject.complete();
		this.marshal.releaseElement(this.nativeElement);
	}
	init(extraTriggers = []) {
		this.marshal.init(this.elementRef.nativeElement, this.DIRECTIVE_KEY, this.updateWithValue.bind(this), this.clearStyles.bind(this), extraTriggers);
	}
	addStyles(input, parent) {
		const builder = this.styleBuilder;
		const useCache = builder.shouldCache;
		let genStyles = this.styleCache.get(input);
		if (!genStyles || !useCache) {
			genStyles = builder.buildStyles(input, parent);
			if (useCache) this.styleCache.set(input, genStyles);
		}
		this.mru = { ...genStyles };
		this.applyStyleToElement(genStyles);
		builder.sideEffect(input, genStyles, parent);
	}
	clearStyles() {
		Object.keys(this.mru).forEach((k) => {
			this.mru[k] = "";
		});
		this.applyStyleToElement(this.mru);
		this.mru = {};
	}
	triggerUpdate() {
		this.marshal.triggerUpdate(this.nativeElement, this.DIRECTIVE_KEY);
	}
	getFlexFlowDirection(target, addIfMissing = false) {
		if (target) {
			const [value, hasInlineValue] = this.styler.getFlowDirection(target);
			if (!hasInlineValue && addIfMissing) {
				const style = buildLayoutCSS(value);
				const elements = [target];
				this.styler.applyStyleToElements(style, elements);
			}
			return value.trim();
		}
		return "row";
	}
	hasWrap(target) {
		return this.styler.hasWrap(target);
	}
	applyStyleToElement(style, value, element = this.nativeElement) {
		this.styler.applyStyleToElement(element, style, value);
	}
	setValue(val, bp) {
		this.marshal.setValue(this.nativeElement, this.DIRECTIVE_KEY, val, bp);
	}
	updateWithValue(input) {
		if (this.currentValue !== input) {
			this.addStyles(input);
			this.currentValue = input;
		}
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: BaseDirective2,
			deps: [
				{ token: i0.ElementRef },
				{ token: StyleBuilder },
				{ token: StyleUtils },
				{ token: MediaMarshaller }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: BaseDirective2,
			isStandalone: true,
			usesOnChanges: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: BaseDirective2,
	decorators: [{ type: Directive }],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: StyleBuilder },
		{ type: StyleUtils },
		{ type: MediaMarshaller }
	]
});
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
var MockMatchMedia = class MockMatchMedia extends MatchMedia {
	constructor(_zone, _platformId, _document, _breakpoints) {
		super(_zone, _platformId, _document);
		this._breakpoints = _breakpoints;
		this.autoRegisterQueries = true;
		this.useOverlaps = false;
	}
	clearAll() {
		this.registry.forEach((mql) => {
			mql.destroy();
		});
		this.registry.clear();
		this.useOverlaps = false;
	}
	activate(mediaQuery, useOverlaps = false) {
		useOverlaps = useOverlaps || this.useOverlaps;
		mediaQuery = this._validateQuery(mediaQuery);
		if (useOverlaps || !this.isActive(mediaQuery)) {
			this._deactivateAll();
			this._registerMediaQuery(mediaQuery);
			this._activateWithOverlaps(mediaQuery, useOverlaps);
		}
		return this.hasActivated;
	}
	_validateQuery(queryOrAlias) {
		const bp = this._breakpoints.findByAlias(queryOrAlias);
		return bp && bp.mediaQuery || queryOrAlias;
	}
	_activateWithOverlaps(mediaQuery, useOverlaps) {
		if (useOverlaps) {
			const bp = this._breakpoints.findByQuery(mediaQuery);
			const alias = bp ? bp.alias : "unknown";
			switch (alias) {
				case "lg":
					this._activateByAlias(["lt-xl"]);
					break;
				case "md":
					this._activateByAlias(["lt-xl", "lt-lg"]);
					break;
				case "sm":
					this._activateByAlias([
						"lt-xl",
						"lt-lg",
						"lt-md"
					]);
					break;
				case "xs": this._activateByAlias([
					"lt-xl",
					"lt-lg",
					"lt-md",
					"lt-sm"
				]);
			}
			switch (alias) {
				case "xl":
					this._activateByAlias([
						"gt-lg",
						"gt-md",
						"gt-sm",
						"gt-xs"
					]);
					break;
				case "lg":
					this._activateByAlias([
						"gt-md",
						"gt-sm",
						"gt-xs"
					]);
					break;
				case "md":
					this._activateByAlias(["gt-sm", "gt-xs"]);
					break;
				case "sm": this._activateByAlias(["gt-xs"]);
			}
		}
		return this._activateByQuery(mediaQuery);
	}
	_activateByAlias(aliases) {
		const activate = (alias) => {
			const bp = this._breakpoints.findByAlias(alias);
			this._activateByQuery(bp ? bp.mediaQuery : alias);
		};
		aliases.forEach(activate);
	}
	_activateByQuery(mediaQuery) {
		if (!this.registry.has(mediaQuery) && this.autoRegisterQueries) this._registerMediaQuery(mediaQuery);
		const mql = this.registry.get(mediaQuery);
		if (mql && !this.isActive(mediaQuery)) this.registry.set(mediaQuery, mql.activate());
		return this.hasActivated;
	}
	_deactivateAll() {
		this.registry.forEach((it) => {
			it.deactivate();
		});
		return this;
	}
	_registerMediaQuery(mediaQuery) {
		if (!this.registry.has(mediaQuery) && this.autoRegisterQueries) this.registerQuery(mediaQuery);
	}
	buildMQL(query) {
		return new MockMediaQueryList(query);
	}
	get hasActivated() {
		return this.activations.length > 0;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MockMatchMedia,
			deps: [
				{ token: i0.NgZone },
				{ token: PLATFORM_ID },
				{ token: DOCUMENT },
				{ token: BreakPointRegistry }
			],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MockMatchMedia
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MockMatchMedia,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [
		{ type: i0.NgZone },
		{
			type: Object,
			decorators: [{
				type: Inject,
				args: [PLATFORM_ID]
			}]
		},
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [DOCUMENT]
			}]
		},
		{ type: BreakPointRegistry }
	]
});
var MockMediaQueryList = class {
	get matches() {
		return this._isActive;
	}
	get media() {
		return this._mediaQuery;
	}
	constructor(_mediaQuery) {
		this._mediaQuery = _mediaQuery;
		this._isActive = false;
		this._listeners = [];
		this.onchange = null;
	}
	destroy() {
		this.deactivate();
		this._listeners = [];
	}
	activate() {
		if (!this._isActive) {
			this._isActive = true;
			this._listeners.forEach((callback) => {
				callback.call(this, {
					matches: this.matches,
					media: this.media
				});
			});
		}
		return this;
	}
	deactivate() {
		if (this._isActive) {
			this._isActive = false;
			this._listeners.forEach((callback) => {
				callback.call(this, {
					matches: this.matches,
					media: this.media
				});
			});
		}
		return this;
	}
	addListener(listener) {
		if (this._listeners.indexOf(listener) === -1) this._listeners.push(listener);
		if (this._isActive) listener.call(this, {
			matches: this.matches,
			media: this.media
		});
	}
	removeListener(_) {}
	addEventListener(_, __, ___) {}
	removeEventListener(_, __, ___) {}
	dispatchEvent(_) {
		return false;
	}
};
const MockMatchMediaProvider = {
	provide: MatchMedia,
	useClass: MockMatchMedia
};
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
function coerceArray(value) {
	return Array.isArray(value) ? value : [value];
}
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
var MediaObserver = class MediaObserver {
	constructor(breakpoints, matchMedia, hook) {
		this.breakpoints = breakpoints;
		this.matchMedia = matchMedia;
		this.hook = hook;
		this.filterOverlaps = false;
		this.destroyed$ = new Subject();
		this._media$ = this.watchActivations();
		this.media$ = this._media$.pipe(filter((changes) => changes.length > 0), map((changes) => changes[0]));
	}
	ngOnDestroy() {
		this.destroyed$.next();
		this.destroyed$.complete();
	}
	asObservable() {
		return this._media$;
	}
	isActive(value) {
		return splitQueries(coerceArray(value)).some((alias) => {
			const query = toMediaQuery(alias, this.breakpoints);
			return query !== null && this.matchMedia.isActive(query);
		});
	}
	watchActivations() {
		const queries = this.breakpoints.items.map((bp) => bp.mediaQuery);
		return this.buildObservable(queries);
	}
	buildObservable(mqList) {
		const hasChanges = (changes) => {
			const isValidQuery = (change) => change.mediaQuery.length > 0;
			return changes.filter(isValidQuery).length > 0;
		};
		const excludeOverlaps = (changes) => {
			return !this.filterOverlaps ? changes : changes.filter((change) => {
				const bp = this.breakpoints.findByQuery(change.mediaQuery);
				return !bp ? true : !bp.overlapping;
			});
		};
		return this.matchMedia.observe(this.hook.withPrintQuery(mqList)).pipe(filter((change) => change.matches), debounceTime(0, asapScheduler), switchMap((_) => of(this.findAllActivations())), map(excludeOverlaps), filter(hasChanges), takeUntil(this.destroyed$));
	}
	findAllActivations() {
		const mergeMQAlias = (change) => {
			return mergeAlias(change, this.breakpoints.findByQuery(change.mediaQuery));
		};
		const replaceWithPrintAlias = (change) => {
			return this.hook.isPrintEvent(change) ? this.hook.updateEvent(change) : change;
		};
		return this.matchMedia.activations.map((query) => new MediaChange(true, query)).map(replaceWithPrintAlias).map(mergeMQAlias).sort(sortDescendingPriority);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MediaObserver,
			deps: [
				{ token: BreakPointRegistry },
				{ token: MatchMedia },
				{ token: PrintHook }
			],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MediaObserver,
			providedIn: "root"
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MediaObserver,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => [
		{ type: BreakPointRegistry },
		{ type: MatchMedia },
		{ type: PrintHook }
	]
});
function toMediaQuery(query, locator) {
	const bp = locator.findByAlias(query) || locator.findByQuery(query);
	return bp ? bp.mediaQuery : null;
}
function splitQueries(queries) {
	return queries.map((query) => query.split(",")).reduce((a1, a2) => a1.concat(a2)).map((query) => query.trim());
}
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
var MediaTrigger = class MediaTrigger {
	constructor(breakpoints, matchMedia, layoutConfig, _platformId, _document) {
		this.breakpoints = breakpoints;
		this.matchMedia = matchMedia;
		this.layoutConfig = layoutConfig;
		this._platformId = _platformId;
		this._document = _document;
		this.hasCachedRegistryMatches = false;
		this.originalActivations = [];
		this.originalRegistry = /* @__PURE__ */ new Map();
	}
	activate(list) {
		list = list.map((it) => it.trim());
		this.saveActivations();
		this.deactivateAll();
		this.setActivations(list);
		this.prepareAutoRestore();
	}
	restore() {
		if (this.hasCachedRegistryMatches) {
			const extractQuery = (change) => change.mediaQuery;
			const list = this.originalActivations.map(extractQuery);
			try {
				this.deactivateAll();
				this.restoreRegistryMatches();
				this.setActivations(list);
			} finally {
				this.originalActivations = [];
				if (this.resizeSubscription) this.resizeSubscription.unsubscribe();
			}
		}
	}
	prepareAutoRestore() {
		if (isPlatformBrowser(this._platformId) && this._document && this.layoutConfig.mediaTriggerAutoRestore) {
			const resize$ = fromEvent(window, "resize").pipe(take(1));
			this.resizeSubscription = resize$.subscribe(this.restore.bind(this));
		}
	}
	deactivateAll() {
		const list = this.currentActivations;
		this.forceRegistryMatches(list, false);
		this.simulateMediaChanges(list, false);
	}
	saveActivations() {
		if (!this.hasCachedRegistryMatches) {
			const toMediaChange = (query) => new MediaChange(true, query);
			const mergeMQAlias = (change) => {
				return mergeAlias(change, this.breakpoints.findByQuery(change.mediaQuery));
			};
			this.originalActivations = this.currentActivations.map(toMediaChange).map(mergeMQAlias).sort(sortDescendingPriority);
			this.cacheRegistryMatches();
		}
	}
	setActivations(list) {
		if (!!this.originalRegistry) this.forceRegistryMatches(list, true);
		this.simulateMediaChanges(list);
	}
	simulateMediaChanges(queries, matches = true) {
		const toMediaQuery = (query) => {
			const locator = this.breakpoints;
			const bp = locator.findByAlias(query) || locator.findByQuery(query);
			return bp ? bp.mediaQuery : query;
		};
		const emitChangeEvent = (query) => this.emitChangeEvent(matches, query);
		queries.map(toMediaQuery).forEach(emitChangeEvent);
	}
	forceRegistryMatches(queries, matches) {
		const registry = /* @__PURE__ */ new Map();
		queries.forEach((query) => {
			registry.set(query, { matches });
		});
		this.matchMedia.registry = registry;
	}
	cacheRegistryMatches() {
		const target = this.originalRegistry;
		target.clear();
		this.matchMedia.registry.forEach((value, key) => {
			target.set(key, value);
		});
		this.hasCachedRegistryMatches = true;
	}
	restoreRegistryMatches() {
		const target = this.matchMedia.registry;
		target.clear();
		this.originalRegistry.forEach((value, key) => {
			target.set(key, value);
		});
		this.originalRegistry.clear();
		this.hasCachedRegistryMatches = false;
	}
	emitChangeEvent(matches, query) {
		this.matchMedia.source.next(new MediaChange(matches, query));
	}
	get currentActivations() {
		return this.matchMedia.activations;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MediaTrigger,
			deps: [
				{ token: BreakPointRegistry },
				{ token: MatchMedia },
				{ token: LAYOUT_CONFIG },
				{ token: PLATFORM_ID },
				{ token: DOCUMENT }
			],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MediaTrigger,
			providedIn: "root"
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MediaTrigger,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => [
		{ type: BreakPointRegistry },
		{ type: MatchMedia },
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [LAYOUT_CONFIG]
			}]
		},
		{
			type: Object,
			decorators: [{
				type: Inject,
				args: [PLATFORM_ID]
			}]
		},
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [DOCUMENT]
			}]
		}
	]
});
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
function validateBasis(basis, grow = "1", shrink = "1") {
	let parts = [
		grow,
		shrink,
		basis
	];
	let j = basis.indexOf("calc");
	if (j > 0) {
		parts[2] = _validateCalcValue(basis.substring(j).trim());
		let matches = basis.substr(0, j).trim().split(" ");
		if (matches.length == 2) {
			parts[0] = matches[0];
			parts[1] = matches[1];
		}
	} else if (j == 0) parts[2] = _validateCalcValue(basis.trim());
	else {
		let matches = basis.split(" ");
		parts = matches.length === 3 ? matches : [
			grow,
			shrink,
			basis
		];
	}
	return parts;
}
function _validateCalcValue(calc) {
	return calc.replace(/[\s]/g, "").replace(/[\/\*\+\-]/g, " $& ");
}
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
export { BREAKPOINT, BREAKPOINTS, BREAKPOINT_PRINT, BROWSER_PROVIDER, BaseDirective2, BreakPointRegistry, CLASS_NAME, CoreModule, DEFAULT_BREAKPOINTS, DEFAULT_CONFIG, LAYOUT_CONFIG, MediaChange, MediaMarshaller, MediaObserver, MediaTrigger, ORIENTATION_BREAKPOINTS, PrintHook, SERVER_TOKEN, ScreenTypes, StyleBuilder, StyleUtils, StylesheetMap, coerceArray, mergeAlias, removeStyles, sortAscendingPriority, sortDescendingPriority, validateBasis, MatchMedia as ɵMatchMedia, MockMatchMedia as ɵMockMatchMedia, MockMatchMediaProvider as ɵMockMatchMediaProvider };

//# sourceMappingURL=angular-flex-layout-core.mjs.map