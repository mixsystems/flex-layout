import * as i0 from "@angular/core";
import { Inject, Injectable, NgModule, PLATFORM_ID } from "@angular/core";
import { DOCUMENT } from "@angular/common";
import { BEFORE_APP_SERIALIZED } from "@angular/platform-server";
import { BREAKPOINTS, CLASS_NAME, LAYOUT_CONFIG, SERVER_TOKEN, StylesheetMap, sortAscendingPriority, ɵMatchMedia } from "@angular/flex-layout/core";
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
var ServerMediaQueryList = class {
	get matches() {
		return this._isActive;
	}
	get media() {
		return this._mediaQuery;
	}
	constructor(_mediaQuery, _isActive = false) {
		this._mediaQuery = _mediaQuery;
		this._isActive = _isActive;
		this._listeners = [];
		this.onchange = null;
	}
	destroy() {
		this.deactivate();
		this._listeners = [];
	}
	activate() {
		if (!this._isActive) {
			this._isActive = true;
			this._listeners.forEach((callback) => {
				callback.call(this, {
					matches: this.matches,
					media: this.media
				});
			});
		}
		return this;
	}
	deactivate() {
		if (this._isActive) {
			this._isActive = false;
			this._listeners.forEach((callback) => {
				callback.call(this, {
					matches: this.matches,
					media: this.media
				});
			});
		}
		return this;
	}
	addListener(listener) {
		if (this._listeners.indexOf(listener) === -1) this._listeners.push(listener);
		if (this._isActive) listener.call(this, {
			matches: this.matches,
			media: this.media
		});
	}
	removeListener(_) {}
	addEventListener(_, __, ___) {}
	removeEventListener(_, __, ___) {}
	dispatchEvent(_) {
		return false;
	}
};
var ServerMatchMedia = class ServerMatchMedia extends ɵMatchMedia {
	constructor(_zone, _platformId, _document, breakpoints, layoutConfig) {
		super(_zone, _platformId, _document);
		this._zone = _zone;
		this._platformId = _platformId;
		this._document = _document;
		this.breakpoints = breakpoints;
		this.layoutConfig = layoutConfig;
		this._activeBreakpoints = [];
		const serverBps = layoutConfig.ssrObserveBreakpoints;
		if (serverBps) this._activeBreakpoints = serverBps.reduce((acc, serverBp) => {
			const foundBp = breakpoints.find((bp) => serverBp === bp.alias);
			if (!foundBp) console.warn(`FlexLayoutServerModule: unknown breakpoint alias "${serverBp}"`);
			else acc.push(foundBp);
			return acc;
		}, []);
	}
	activateBreakpoint(bp) {
		const lookupBreakpoint = this.registry.get(bp.mediaQuery);
		if (lookupBreakpoint) lookupBreakpoint.activate();
	}
	deactivateBreakpoint(bp) {
		const lookupBreakpoint = this.registry.get(bp.mediaQuery);
		if (lookupBreakpoint) lookupBreakpoint.deactivate();
	}
	buildMQL(query) {
		return new ServerMediaQueryList(query, this._activeBreakpoints.some((ab) => ab.mediaQuery === query));
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: ServerMatchMedia,
			deps: [
				{ token: i0.NgZone },
				{ token: PLATFORM_ID },
				{ token: DOCUMENT },
				{ token: BREAKPOINTS },
				{ token: LAYOUT_CONFIG }
			],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: ServerMatchMedia
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ServerMatchMedia,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [
		{ type: i0.NgZone },
		{
			type: Object,
			decorators: [{
				type: Inject,
				args: [PLATFORM_ID]
			}]
		},
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [DOCUMENT]
			}]
		},
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [BREAKPOINTS]
			}]
		},
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [LAYOUT_CONFIG]
			}]
		}
	]
});
function generateStaticFlexLayoutStyles(serverSheet, mediaController, breakpoints) {
	const classMap = /* @__PURE__ */ new Map();
	const defaultStyles = new Map(serverSheet.stylesheet);
	nextId = 0;
	let styleText = generateCss(defaultStyles, "all", classMap);
	[...breakpoints].sort(sortAscendingPriority).forEach((bp, i) => {
		serverSheet.clearStyles();
		mediaController.activateBreakpoint(bp);
		const stylesheet = new Map(serverSheet.stylesheet);
		if (stylesheet.size > 0) styleText += generateCss(stylesheet, bp.mediaQuery, classMap);
		mediaController.deactivateBreakpoint(breakpoints[i]);
	});
	return styleText;
}
function FLEX_SSR_SERIALIZER_FACTORY(serverSheet, mediaController, _document, breakpoints) {
	return () => {
		const styleTag = _document.createElement("style");
		const styleText = generateStaticFlexLayoutStyles(serverSheet, mediaController, breakpoints);
		styleTag.classList.add(`${CLASS_NAME}ssr`);
		styleTag.textContent = styleText;
		_document.head.appendChild(styleTag);
	};
}
const SERVER_PROVIDERS = [
	{
		provide: BEFORE_APP_SERIALIZED,
		useFactory: FLEX_SSR_SERIALIZER_FACTORY,
		deps: [
			StylesheetMap,
			ɵMatchMedia,
			DOCUMENT,
			BREAKPOINTS
		],
		multi: true
	},
	{
		provide: SERVER_TOKEN,
		useValue: true
	},
	{
		provide: ɵMatchMedia,
		useClass: ServerMatchMedia
	}
];
let nextId = 0;
function generateCss(stylesheet, mediaQuery, classMap) {
	let css = "";
	stylesheet.forEach((styles, el) => {
		let keyVals = "";
		let className = getClassName(el, classMap);
		styles.forEach((v, k) => {
			keyVals += v ? format(`${k}:${v};`) : "";
		});
		css += format(`.${className} {`, keyVals, "}");
	});
	return format(`@media ${mediaQuery} {`, css, "}");
}
function format(...list) {
	let result = "";
	list.forEach((css, i) => {
		result += css;
	});
	return result;
}
function getClassName(element, classMap) {
	let className = classMap.get(element);
	if (!className) {
		className = `${CLASS_NAME}${nextId++}`;
		classMap.set(element, className);
	}
	element.classList.add(className);
	return className;
}
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
var FlexLayoutServerModule = class FlexLayoutServerModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: FlexLayoutServerModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: FlexLayoutServerModule
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: FlexLayoutServerModule,
			providers: [SERVER_PROVIDERS]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FlexLayoutServerModule,
	decorators: [{
		type: NgModule,
		args: [{ providers: [SERVER_PROVIDERS] }]
	}]
});
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
export { FLEX_SSR_SERIALIZER_FACTORY, FlexLayoutServerModule, SERVER_PROVIDERS, generateStaticFlexLayoutStyles };

//# sourceMappingURL=angular-flex-layout-server.mjs.map