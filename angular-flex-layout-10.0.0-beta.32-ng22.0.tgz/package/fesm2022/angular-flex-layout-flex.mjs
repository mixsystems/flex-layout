import * as i0 from "@angular/core";
import { Directive, Inject, Injectable, Input, NgModule } from "@angular/core";
import * as i2 from "@angular/cdk/bidi";
import { BidiModule } from "@angular/cdk/bidi";
import * as i1 from "@angular/flex-layout/core";
import { BaseDirective2, CoreModule, LAYOUT_CONFIG, StyleBuilder, validateBasis } from "@angular/flex-layout/core";
import { LAYOUT_VALUES, buildLayoutCSS, extendObject, isFlowHorizontal } from "@angular/flex-layout/_private-utils";
import { Subject } from "rxjs";
import { takeUntil } from "rxjs/operators";
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
var LayoutStyleBuilder = class LayoutStyleBuilder extends StyleBuilder {
	buildStyles(input) {
		return buildLayoutCSS(input);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: LayoutStyleBuilder,
			deps: null,
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: LayoutStyleBuilder,
			providedIn: "root"
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: LayoutStyleBuilder,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
const inputs$6 = [
	"fxLayout",
	"fxLayout.xs",
	"fxLayout.sm",
	"fxLayout.md",
	"fxLayout.lg",
	"fxLayout.xl",
	"fxLayout.lt-sm",
	"fxLayout.lt-md",
	"fxLayout.lt-lg",
	"fxLayout.lt-xl",
	"fxLayout.gt-xs",
	"fxLayout.gt-sm",
	"fxLayout.gt-md",
	"fxLayout.gt-lg"
];
const selector$6 = `
  [fxLayout], [fxLayout.xs], [fxLayout.sm], [fxLayout.md],
  [fxLayout.lg], [fxLayout.xl], [fxLayout.lt-sm], [fxLayout.lt-md],
  [fxLayout.lt-lg], [fxLayout.lt-xl], [fxLayout.gt-xs], [fxLayout.gt-sm],
  [fxLayout.gt-md], [fxLayout.gt-lg]
`;
var LayoutDirective = class LayoutDirective extends BaseDirective2 {
	constructor(elRef, styleUtils, styleBuilder, marshal) {
		super(elRef, styleBuilder, styleUtils, marshal);
		this.DIRECTIVE_KEY = "layout";
		this.styleCache = layoutCache;
		this.init();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: LayoutDirective,
			deps: [
				{ token: i0.ElementRef },
				{ token: i1.StyleUtils },
				{ token: LayoutStyleBuilder },
				{ token: i1.MediaMarshaller }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: LayoutDirective,
			isStandalone: true,
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: LayoutDirective,
	decorators: [{ type: Directive }],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: i1.StyleUtils },
		{ type: LayoutStyleBuilder },
		{ type: i1.MediaMarshaller }
	]
});
var DefaultLayoutDirective = class DefaultLayoutDirective extends LayoutDirective {
	constructor() {
		super(...arguments);
		this.inputs = inputs$6;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: DefaultLayoutDirective,
			deps: null,
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: DefaultLayoutDirective,
			isStandalone: false,
			selector: "\n  [fxLayout], [fxLayout.xs], [fxLayout.sm], [fxLayout.md],\n  [fxLayout.lg], [fxLayout.xl], [fxLayout.lt-sm], [fxLayout.lt-md],\n  [fxLayout.lt-lg], [fxLayout.lt-xl], [fxLayout.gt-xs], [fxLayout.gt-sm],\n  [fxLayout.gt-md], [fxLayout.gt-lg]\n",
			inputs: {
				fxLayout: "fxLayout",
				"fxLayout.xs": "fxLayout.xs",
				"fxLayout.sm": "fxLayout.sm",
				"fxLayout.md": "fxLayout.md",
				"fxLayout.lg": "fxLayout.lg",
				"fxLayout.xl": "fxLayout.xl",
				"fxLayout.lt-sm": "fxLayout.lt-sm",
				"fxLayout.lt-md": "fxLayout.lt-md",
				"fxLayout.lt-lg": "fxLayout.lt-lg",
				"fxLayout.lt-xl": "fxLayout.lt-xl",
				"fxLayout.gt-xs": "fxLayout.gt-xs",
				"fxLayout.gt-sm": "fxLayout.gt-sm",
				"fxLayout.gt-md": "fxLayout.gt-md",
				"fxLayout.gt-lg": "fxLayout.gt-lg"
			},
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DefaultLayoutDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: selector$6,
			inputs: inputs$6,
			standalone: false
		}]
	}]
});
const layoutCache = /* @__PURE__ */ new Map();
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
const CLEAR_MARGIN_CSS = {
	"margin-left": null,
	"margin-right": null,
	"margin-top": null,
	"margin-bottom": null
};
var LayoutGapStyleBuilder = class LayoutGapStyleBuilder extends StyleBuilder {
	constructor(_styler) {
		super();
		this._styler = _styler;
	}
	buildStyles(gapValue, parent) {
		if (gapValue.endsWith(GRID_SPECIFIER)) {
			gapValue = gapValue.slice(0, gapValue.indexOf(GRID_SPECIFIER));
			return buildGridMargin(gapValue, parent.directionality);
		} else return {};
	}
	sideEffect(gapValue, _styles, parent) {
		const items = parent.items;
		if (gapValue.endsWith(GRID_SPECIFIER)) {
			gapValue = gapValue.slice(0, gapValue.indexOf(GRID_SPECIFIER));
			const paddingStyles = buildGridPadding(gapValue, parent.directionality);
			this._styler.applyStyleToElements(paddingStyles, parent.items);
		} else {
			const lastItem = items.pop();
			const gapCss = buildGapCSS(gapValue, parent);
			this._styler.applyStyleToElements(gapCss, items);
			this._styler.applyStyleToElements(CLEAR_MARGIN_CSS, [lastItem]);
		}
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: LayoutGapStyleBuilder,
			deps: [{ token: i1.StyleUtils }],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: LayoutGapStyleBuilder,
			providedIn: "root"
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: LayoutGapStyleBuilder,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => [{ type: i1.StyleUtils }]
});
const inputs$5 = [
	"fxLayoutGap",
	"fxLayoutGap.xs",
	"fxLayoutGap.sm",
	"fxLayoutGap.md",
	"fxLayoutGap.lg",
	"fxLayoutGap.xl",
	"fxLayoutGap.lt-sm",
	"fxLayoutGap.lt-md",
	"fxLayoutGap.lt-lg",
	"fxLayoutGap.lt-xl",
	"fxLayoutGap.gt-xs",
	"fxLayoutGap.gt-sm",
	"fxLayoutGap.gt-md",
	"fxLayoutGap.gt-lg"
];
const selector$5 = `
  [fxLayoutGap], [fxLayoutGap.xs], [fxLayoutGap.sm], [fxLayoutGap.md],
  [fxLayoutGap.lg], [fxLayoutGap.xl], [fxLayoutGap.lt-sm], [fxLayoutGap.lt-md],
  [fxLayoutGap.lt-lg], [fxLayoutGap.lt-xl], [fxLayoutGap.gt-xs], [fxLayoutGap.gt-sm],
  [fxLayoutGap.gt-md], [fxLayoutGap.gt-lg]
`;
var LayoutGapDirective = class LayoutGapDirective extends BaseDirective2 {
	get childrenNodes() {
		const obj = this.nativeElement.children;
		const buffer = [];
		for (let i = obj.length; i--;) buffer[i] = obj[i];
		return buffer;
	}
	constructor(elRef, zone, directionality, styleUtils, styleBuilder, marshal) {
		super(elRef, styleBuilder, styleUtils, marshal);
		this.zone = zone;
		this.directionality = directionality;
		this.styleUtils = styleUtils;
		this.layout = "row";
		this.DIRECTIVE_KEY = "layout-gap";
		this.observerSubject = new Subject();
		const extraTriggers = [this.directionality.change, this.observerSubject.asObservable()];
		this.init(extraTriggers);
		this.marshal.trackValue(this.nativeElement, "layout").pipe(takeUntil(this.destroySubject)).subscribe(this.onLayoutChange.bind(this));
	}
	ngAfterContentInit() {
		this.buildChildObservable();
		this.triggerUpdate();
	}
	ngOnDestroy() {
		super.ngOnDestroy();
		if (this.observer) this.observer.disconnect();
	}
	onLayoutChange(matcher) {
		const direction = matcher.value.split(" ");
		this.layout = direction[0];
		if (!LAYOUT_VALUES.find((x) => x === this.layout)) this.layout = "row";
		this.triggerUpdate();
	}
	updateWithValue(value) {
		const items = this.childrenNodes.filter((el) => el.nodeType === 1 && this.willDisplay(el)).sort((a, b) => {
			const orderA = +this.styler.lookupStyle(a, "order");
			const orderB = +this.styler.lookupStyle(b, "order");
			if (isNaN(orderA) || isNaN(orderB) || orderA === orderB) return 0;
			else return orderA > orderB ? 1 : -1;
		});
		if (items.length > 0) {
			const directionality = this.directionality.value;
			const layout = this.layout;
			if (layout === "row" && directionality === "rtl") this.styleCache = layoutGapCacheRowRtl;
			else if (layout === "row" && directionality !== "rtl") this.styleCache = layoutGapCacheRowLtr;
			else if (layout === "column" && directionality === "rtl") this.styleCache = layoutGapCacheColumnRtl;
			else if (layout === "column" && directionality !== "rtl") this.styleCache = layoutGapCacheColumnLtr;
			this.addStyles(value, {
				directionality,
				items,
				layout
			});
		}
	}
	clearStyles() {
		const gridMode = Object.keys(this.mru).length > 0;
		const childrenStyle = gridMode ? "padding" : getMarginType(this.directionality.value, this.layout);
		if (gridMode) super.clearStyles();
		this.styleUtils.applyStyleToElements({ [childrenStyle]: "" }, this.childrenNodes);
	}
	willDisplay(source) {
		const value = this.marshal.getValue(source, "show-hide");
		return value === true || value === void 0 && this.styleUtils.lookupStyle(source, "display") !== "none";
	}
	buildChildObservable() {
		this.zone.runOutsideAngular(() => {
			if (typeof MutationObserver !== "undefined") {
				this.observer = new MutationObserver((mutations) => {
					const validatedChanges = (it) => {
						return it.addedNodes && it.addedNodes.length > 0 || it.removedNodes && it.removedNodes.length > 0;
					};
					if (mutations.some(validatedChanges)) this.observerSubject.next();
				});
				this.observer.observe(this.nativeElement, { childList: true });
			}
		});
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: LayoutGapDirective,
			deps: [
				{ token: i0.ElementRef },
				{ token: i0.NgZone },
				{ token: i2.Directionality },
				{ token: i1.StyleUtils },
				{ token: LayoutGapStyleBuilder },
				{ token: i1.MediaMarshaller }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: LayoutGapDirective,
			isStandalone: true,
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: LayoutGapDirective,
	decorators: [{ type: Directive }],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: i0.NgZone },
		{ type: i2.Directionality },
		{ type: i1.StyleUtils },
		{ type: LayoutGapStyleBuilder },
		{ type: i1.MediaMarshaller }
	]
});
var DefaultLayoutGapDirective = class DefaultLayoutGapDirective extends LayoutGapDirective {
	constructor() {
		super(...arguments);
		this.inputs = inputs$5;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: DefaultLayoutGapDirective,
			deps: null,
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: DefaultLayoutGapDirective,
			isStandalone: false,
			selector: "\n  [fxLayoutGap], [fxLayoutGap.xs], [fxLayoutGap.sm], [fxLayoutGap.md],\n  [fxLayoutGap.lg], [fxLayoutGap.xl], [fxLayoutGap.lt-sm], [fxLayoutGap.lt-md],\n  [fxLayoutGap.lt-lg], [fxLayoutGap.lt-xl], [fxLayoutGap.gt-xs], [fxLayoutGap.gt-sm],\n  [fxLayoutGap.gt-md], [fxLayoutGap.gt-lg]\n",
			inputs: {
				fxLayoutGap: "fxLayoutGap",
				"fxLayoutGap.xs": "fxLayoutGap.xs",
				"fxLayoutGap.sm": "fxLayoutGap.sm",
				"fxLayoutGap.md": "fxLayoutGap.md",
				"fxLayoutGap.lg": "fxLayoutGap.lg",
				"fxLayoutGap.xl": "fxLayoutGap.xl",
				"fxLayoutGap.lt-sm": "fxLayoutGap.lt-sm",
				"fxLayoutGap.lt-md": "fxLayoutGap.lt-md",
				"fxLayoutGap.lt-lg": "fxLayoutGap.lt-lg",
				"fxLayoutGap.lt-xl": "fxLayoutGap.lt-xl",
				"fxLayoutGap.gt-xs": "fxLayoutGap.gt-xs",
				"fxLayoutGap.gt-sm": "fxLayoutGap.gt-sm",
				"fxLayoutGap.gt-md": "fxLayoutGap.gt-md",
				"fxLayoutGap.gt-lg": "fxLayoutGap.gt-lg"
			},
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DefaultLayoutGapDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: selector$5,
			inputs: inputs$5,
			standalone: false
		}]
	}]
});
const layoutGapCacheRowRtl = /* @__PURE__ */ new Map();
const layoutGapCacheColumnRtl = /* @__PURE__ */ new Map();
const layoutGapCacheRowLtr = /* @__PURE__ */ new Map();
const layoutGapCacheColumnLtr = /* @__PURE__ */ new Map();
const GRID_SPECIFIER = " grid";
function buildGridPadding(value, directionality) {
	const [between, below] = value.split(" ");
	const bottom = below || between;
	let paddingRight = "0px", paddingBottom = bottom, paddingLeft = "0px";
	if (directionality === "rtl") paddingLeft = between;
	else paddingRight = between;
	return { "padding": `0px ${paddingRight} ${paddingBottom} ${paddingLeft}` };
}
function buildGridMargin(value, directionality) {
	const [between, below] = value.split(" ");
	const bottom = below || between;
	const minus = (str) => `-${str}`;
	let marginRight = "0px", marginBottom = minus(bottom), marginLeft = "0px";
	if (directionality === "rtl") marginLeft = minus(between);
	else marginRight = minus(between);
	return { "margin": `0px ${marginRight} ${marginBottom} ${marginLeft}` };
}
function getMarginType(directionality, layout) {
	switch (layout) {
		case "column": return "margin-bottom";
		case "column-reverse": return "margin-top";
		case "row": return directionality === "rtl" ? "margin-left" : "margin-right";
		case "row-reverse": return directionality === "rtl" ? "margin-right" : "margin-left";
		default: return directionality === "rtl" ? "margin-left" : "margin-right";
	}
}
function buildGapCSS(gapValue, parent) {
	const key = getMarginType(parent.directionality, parent.layout);
	const margins = { ...CLEAR_MARGIN_CSS };
	margins[key] = gapValue;
	return margins;
}
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
var FlexStyleBuilder = class FlexStyleBuilder extends StyleBuilder {
	constructor(layoutConfig) {
		super();
		this.layoutConfig = layoutConfig;
	}
	buildStyles(input, parent) {
		let [grow, shrink, ...basisParts] = input.split(" ");
		let basis = basisParts.join(" ");
		const direction = parent.direction.indexOf("column") > -1 ? "column" : "row";
		const max = isFlowHorizontal(direction) ? "max-width" : "max-height";
		const min = isFlowHorizontal(direction) ? "min-width" : "min-height";
		const hasCalc = String(basis).indexOf("calc") > -1;
		const usingCalc = hasCalc || basis === "auto";
		const isPercent = String(basis).indexOf("%") > -1 && !hasCalc;
		const hasUnits = String(basis).indexOf("px") > -1 || String(basis).indexOf("rem") > -1 || String(basis).indexOf("em") > -1 || String(basis).indexOf("vw") > -1 || String(basis).indexOf("vh") > -1;
		let isValue = hasCalc || hasUnits;
		grow = grow == "0" ? 0 : grow;
		shrink = shrink == "0" ? 0 : shrink;
		const isFixed = !grow && !shrink;
		let css = {};
		const clearStyles = {
			"max-width": null,
			"max-height": null,
			"min-width": null,
			"min-height": null
		};
		switch (basis || "") {
			case "":
				const useColumnBasisZero = this.layoutConfig.useColumnBasisZero !== false;
				basis = direction === "row" ? "0%" : useColumnBasisZero ? "0.000000001px" : "auto";
				break;
			case "initial":
			case "nogrow":
				grow = 0;
				basis = "auto";
				break;
			case "grow":
				basis = "100%";
				break;
			case "noshrink":
				shrink = 0;
				basis = "auto";
				break;
			case "auto": break;
			case "none":
				grow = 0;
				shrink = 0;
				basis = "auto";
				break;
			default:
				if (!isValue && !isPercent && !isNaN(basis)) basis = basis + "%";
				if (basis === "0%") isValue = true;
				if (basis === "0px") basis = "0%";
				if (hasCalc) css = extendObject(clearStyles, {
					"flex-grow": grow,
					"flex-shrink": shrink,
					"flex-basis": isValue ? basis : "100%"
				});
				else css = extendObject(clearStyles, { "flex": `${grow} ${shrink} ${isValue ? basis : "100%"}` });
		}
		if (!(css["flex"] || css["flex-grow"])) {
			if (hasCalc) css = extendObject(clearStyles, {
				"flex-grow": grow,
				"flex-shrink": shrink,
				"flex-basis": basis
			});
			else css = extendObject(clearStyles, { "flex": `${grow} ${shrink} ${basis}` });
		}
		if (basis !== "0%" && basis !== "0px" && basis !== "0.000000001px" && basis !== "auto") {
			css[min] = isFixed || isValue && grow ? basis : null;
			css[max] = isFixed || !usingCalc && shrink ? basis : null;
		}
		if (!css[min] && !css[max]) {
			if (hasCalc) css = extendObject(clearStyles, {
				"flex-grow": grow,
				"flex-shrink": shrink,
				"flex-basis": basis
			});
			else css = extendObject(clearStyles, { "flex": `${grow} ${shrink} ${basis}` });
		} else if (parent.hasWrap) css[hasCalc ? "flex-basis" : "flex"] = css[max] ? hasCalc ? css[max] : `${grow} ${shrink} ${css[max]}` : hasCalc ? css[min] : `${grow} ${shrink} ${css[min]}`;
		return extendObject(css, { "box-sizing": "border-box" });
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: FlexStyleBuilder,
			deps: [{ token: LAYOUT_CONFIG }],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: FlexStyleBuilder,
			providedIn: "root"
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FlexStyleBuilder,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => [{
		type: void 0,
		decorators: [{
			type: Inject,
			args: [LAYOUT_CONFIG]
		}]
	}]
});
const inputs$4 = [
	"fxFlex",
	"fxFlex.xs",
	"fxFlex.sm",
	"fxFlex.md",
	"fxFlex.lg",
	"fxFlex.xl",
	"fxFlex.lt-sm",
	"fxFlex.lt-md",
	"fxFlex.lt-lg",
	"fxFlex.lt-xl",
	"fxFlex.gt-xs",
	"fxFlex.gt-sm",
	"fxFlex.gt-md",
	"fxFlex.gt-lg"
];
const selector$4 = `
  [fxFlex], [fxFlex.xs], [fxFlex.sm], [fxFlex.md],
  [fxFlex.lg], [fxFlex.xl], [fxFlex.lt-sm], [fxFlex.lt-md],
  [fxFlex.lt-lg], [fxFlex.lt-xl], [fxFlex.gt-xs], [fxFlex.gt-sm],
  [fxFlex.gt-md], [fxFlex.gt-lg]
`;
var FlexDirective = class FlexDirective extends BaseDirective2 {
	get shrink() {
		return this.flexShrink;
	}
	set shrink(value) {
		this.flexShrink = value || "1";
		this.triggerReflow();
	}
	get grow() {
		return this.flexGrow;
	}
	set grow(value) {
		this.flexGrow = value || "1";
		this.triggerReflow();
	}
	constructor(elRef, styleUtils, layoutConfig, styleBuilder, marshal) {
		super(elRef, styleBuilder, styleUtils, marshal);
		this.layoutConfig = layoutConfig;
		this.marshal = marshal;
		this.DIRECTIVE_KEY = "flex";
		this.direction = void 0;
		this.wrap = void 0;
		this.flexGrow = "1";
		this.flexShrink = "1";
		this.init();
	}
	ngOnInit() {
		if (this.parentElement) {
			this.marshal.trackValue(this.parentElement, "layout").pipe(takeUntil(this.destroySubject)).subscribe(this.onLayoutChange.bind(this));
			this.marshal.trackValue(this.nativeElement, "layout-align").pipe(takeUntil(this.destroySubject)).subscribe(this.triggerReflow.bind(this));
		}
	}
	onLayoutChange(matcher) {
		const layoutParts = matcher.value.split(" ");
		this.direction = layoutParts[0];
		this.wrap = layoutParts[1] !== void 0 && layoutParts[1] === "wrap";
		this.triggerUpdate();
	}
	updateWithValue(value) {
		const addFlexToParent = this.layoutConfig.addFlexToParent !== false;
		if (this.direction === void 0) this.direction = this.getFlexFlowDirection(this.parentElement, addFlexToParent);
		if (this.wrap === void 0) this.wrap = this.hasWrap(this.parentElement);
		const direction = this.direction;
		const isHorizontal = direction.startsWith("row");
		const hasWrap = this.wrap;
		if (isHorizontal && hasWrap) this.styleCache = flexRowWrapCache;
		else if (isHorizontal && !hasWrap) this.styleCache = flexRowCache;
		else if (!isHorizontal && hasWrap) this.styleCache = flexColumnWrapCache;
		else if (!isHorizontal && !hasWrap) this.styleCache = flexColumnCache;
		const basis = String(value).replace(";", "");
		const parts = validateBasis(basis, this.flexGrow, this.flexShrink);
		this.addStyles(parts.join(" "), {
			direction,
			hasWrap
		});
	}
	triggerReflow() {
		const activatedValue = this.activatedValue;
		if (activatedValue !== void 0) {
			const parts = validateBasis(activatedValue + "", this.flexGrow, this.flexShrink);
			this.marshal.updateElement(this.nativeElement, this.DIRECTIVE_KEY, parts.join(" "));
		}
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: FlexDirective,
			deps: [
				{ token: i0.ElementRef },
				{ token: i1.StyleUtils },
				{ token: LAYOUT_CONFIG },
				{ token: FlexStyleBuilder },
				{ token: i1.MediaMarshaller }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: FlexDirective,
			isStandalone: true,
			inputs: {
				shrink: ["fxShrink", "shrink"],
				grow: ["fxGrow", "grow"]
			},
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FlexDirective,
	decorators: [{ type: Directive }],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: i1.StyleUtils },
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [LAYOUT_CONFIG]
			}]
		},
		{ type: FlexStyleBuilder },
		{ type: i1.MediaMarshaller }
	],
	propDecorators: {
		shrink: [{
			type: Input,
			args: ["fxShrink"]
		}],
		grow: [{
			type: Input,
			args: ["fxGrow"]
		}]
	}
});
var DefaultFlexDirective = class DefaultFlexDirective extends FlexDirective {
	constructor() {
		super(...arguments);
		this.inputs = inputs$4;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: DefaultFlexDirective,
			deps: null,
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: DefaultFlexDirective,
			isStandalone: false,
			selector: "\n  [fxFlex], [fxFlex.xs], [fxFlex.sm], [fxFlex.md],\n  [fxFlex.lg], [fxFlex.xl], [fxFlex.lt-sm], [fxFlex.lt-md],\n  [fxFlex.lt-lg], [fxFlex.lt-xl], [fxFlex.gt-xs], [fxFlex.gt-sm],\n  [fxFlex.gt-md], [fxFlex.gt-lg]\n",
			inputs: {
				fxFlex: "fxFlex",
				"fxFlex.xs": "fxFlex.xs",
				"fxFlex.sm": "fxFlex.sm",
				"fxFlex.md": "fxFlex.md",
				"fxFlex.lg": "fxFlex.lg",
				"fxFlex.xl": "fxFlex.xl",
				"fxFlex.lt-sm": "fxFlex.lt-sm",
				"fxFlex.lt-md": "fxFlex.lt-md",
				"fxFlex.lt-lg": "fxFlex.lt-lg",
				"fxFlex.lt-xl": "fxFlex.lt-xl",
				"fxFlex.gt-xs": "fxFlex.gt-xs",
				"fxFlex.gt-sm": "fxFlex.gt-sm",
				"fxFlex.gt-md": "fxFlex.gt-md",
				"fxFlex.gt-lg": "fxFlex.gt-lg"
			},
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DefaultFlexDirective,
	decorators: [{
		type: Directive,
		args: [{
			inputs: inputs$4,
			selector: selector$4,
			standalone: false
		}]
	}]
});
const flexRowCache = /* @__PURE__ */ new Map();
const flexColumnCache = /* @__PURE__ */ new Map();
const flexRowWrapCache = /* @__PURE__ */ new Map();
const flexColumnWrapCache = /* @__PURE__ */ new Map();
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
var FlexOrderStyleBuilder = class FlexOrderStyleBuilder extends StyleBuilder {
	buildStyles(value) {
		return { order: value && parseInt(value, 10) || "" };
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: FlexOrderStyleBuilder,
			deps: null,
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: FlexOrderStyleBuilder,
			providedIn: "root"
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FlexOrderStyleBuilder,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
const inputs$3 = [
	"fxFlexOrder",
	"fxFlexOrder.xs",
	"fxFlexOrder.sm",
	"fxFlexOrder.md",
	"fxFlexOrder.lg",
	"fxFlexOrder.xl",
	"fxFlexOrder.lt-sm",
	"fxFlexOrder.lt-md",
	"fxFlexOrder.lt-lg",
	"fxFlexOrder.lt-xl",
	"fxFlexOrder.gt-xs",
	"fxFlexOrder.gt-sm",
	"fxFlexOrder.gt-md",
	"fxFlexOrder.gt-lg"
];
const selector$3 = `
  [fxFlexOrder], [fxFlexOrder.xs], [fxFlexOrder.sm], [fxFlexOrder.md],
  [fxFlexOrder.lg], [fxFlexOrder.xl], [fxFlexOrder.lt-sm], [fxFlexOrder.lt-md],
  [fxFlexOrder.lt-lg], [fxFlexOrder.lt-xl], [fxFlexOrder.gt-xs], [fxFlexOrder.gt-sm],
  [fxFlexOrder.gt-md], [fxFlexOrder.gt-lg]
`;
var FlexOrderDirective = class FlexOrderDirective extends BaseDirective2 {
	constructor(elRef, styleUtils, styleBuilder, marshal) {
		super(elRef, styleBuilder, styleUtils, marshal);
		this.DIRECTIVE_KEY = "flex-order";
		this.styleCache = flexOrderCache;
		this.init();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: FlexOrderDirective,
			deps: [
				{ token: i0.ElementRef },
				{ token: i1.StyleUtils },
				{ token: FlexOrderStyleBuilder },
				{ token: i1.MediaMarshaller }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: FlexOrderDirective,
			isStandalone: true,
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FlexOrderDirective,
	decorators: [{ type: Directive }],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: i1.StyleUtils },
		{ type: FlexOrderStyleBuilder },
		{ type: i1.MediaMarshaller }
	]
});
const flexOrderCache = /* @__PURE__ */ new Map();
var DefaultFlexOrderDirective = class DefaultFlexOrderDirective extends FlexOrderDirective {
	constructor() {
		super(...arguments);
		this.inputs = inputs$3;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: DefaultFlexOrderDirective,
			deps: null,
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: DefaultFlexOrderDirective,
			isStandalone: false,
			selector: "\n  [fxFlexOrder], [fxFlexOrder.xs], [fxFlexOrder.sm], [fxFlexOrder.md],\n  [fxFlexOrder.lg], [fxFlexOrder.xl], [fxFlexOrder.lt-sm], [fxFlexOrder.lt-md],\n  [fxFlexOrder.lt-lg], [fxFlexOrder.lt-xl], [fxFlexOrder.gt-xs], [fxFlexOrder.gt-sm],\n  [fxFlexOrder.gt-md], [fxFlexOrder.gt-lg]\n",
			inputs: {
				fxFlexOrder: "fxFlexOrder",
				"fxFlexOrder.xs": "fxFlexOrder.xs",
				"fxFlexOrder.sm": "fxFlexOrder.sm",
				"fxFlexOrder.md": "fxFlexOrder.md",
				"fxFlexOrder.lg": "fxFlexOrder.lg",
				"fxFlexOrder.xl": "fxFlexOrder.xl",
				"fxFlexOrder.lt-sm": "fxFlexOrder.lt-sm",
				"fxFlexOrder.lt-md": "fxFlexOrder.lt-md",
				"fxFlexOrder.lt-lg": "fxFlexOrder.lt-lg",
				"fxFlexOrder.lt-xl": "fxFlexOrder.lt-xl",
				"fxFlexOrder.gt-xs": "fxFlexOrder.gt-xs",
				"fxFlexOrder.gt-sm": "fxFlexOrder.gt-sm",
				"fxFlexOrder.gt-md": "fxFlexOrder.gt-md",
				"fxFlexOrder.gt-lg": "fxFlexOrder.gt-lg"
			},
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DefaultFlexOrderDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: selector$3,
			inputs: inputs$3,
			standalone: false
		}]
	}]
});
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
var FlexOffsetStyleBuilder = class FlexOffsetStyleBuilder extends StyleBuilder {
	buildStyles(offset, parent) {
		if (offset === "") offset = "0";
		const isPercent = String(offset).indexOf("%") > -1;
		if (!(String(offset).indexOf("px") > -1) && !isPercent && !isNaN(+offset)) offset = offset + "%";
		const horizontalLayoutKey = parent.isRtl ? "margin-right" : "margin-left";
		return isFlowHorizontal(parent.layout) ? { [horizontalLayoutKey]: `${offset}` } : { "margin-top": `${offset}` };
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: FlexOffsetStyleBuilder,
			deps: null,
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: FlexOffsetStyleBuilder,
			providedIn: "root"
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FlexOffsetStyleBuilder,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
const inputs$2 = [
	"fxFlexOffset",
	"fxFlexOffset.xs",
	"fxFlexOffset.sm",
	"fxFlexOffset.md",
	"fxFlexOffset.lg",
	"fxFlexOffset.xl",
	"fxFlexOffset.lt-sm",
	"fxFlexOffset.lt-md",
	"fxFlexOffset.lt-lg",
	"fxFlexOffset.lt-xl",
	"fxFlexOffset.gt-xs",
	"fxFlexOffset.gt-sm",
	"fxFlexOffset.gt-md",
	"fxFlexOffset.gt-lg"
];
const selector$2 = `
  [fxFlexOffset], [fxFlexOffset.xs], [fxFlexOffset.sm], [fxFlexOffset.md],
  [fxFlexOffset.lg], [fxFlexOffset.xl], [fxFlexOffset.lt-sm], [fxFlexOffset.lt-md],
  [fxFlexOffset.lt-lg], [fxFlexOffset.lt-xl], [fxFlexOffset.gt-xs], [fxFlexOffset.gt-sm],
  [fxFlexOffset.gt-md], [fxFlexOffset.gt-lg]
`;
var FlexOffsetDirective = class FlexOffsetDirective extends BaseDirective2 {
	constructor(elRef, directionality, styleBuilder, marshal, styler) {
		super(elRef, styleBuilder, styler, marshal);
		this.directionality = directionality;
		this.DIRECTIVE_KEY = "flex-offset";
		this.init([this.directionality.change]);
		if (this.parentElement) this.marshal.trackValue(this.parentElement, "layout-gap").pipe(takeUntil(this.destroySubject)).subscribe(this.triggerUpdate.bind(this));
	}
	updateWithValue(value = "") {
		const layout = this.getFlexFlowDirection(this.parentElement, true);
		const isRtl = this.directionality.value === "rtl";
		if (layout === "row" && isRtl) this.styleCache = flexOffsetCacheRowRtl;
		else if (layout === "row" && !isRtl) this.styleCache = flexOffsetCacheRowLtr;
		else if (layout === "column" && isRtl) this.styleCache = flexOffsetCacheColumnRtl;
		else if (layout === "column" && !isRtl) this.styleCache = flexOffsetCacheColumnLtr;
		this.addStyles(value + "", {
			layout,
			isRtl
		});
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: FlexOffsetDirective,
			deps: [
				{ token: i0.ElementRef },
				{ token: i2.Directionality },
				{ token: FlexOffsetStyleBuilder },
				{ token: i1.MediaMarshaller },
				{ token: i1.StyleUtils }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: FlexOffsetDirective,
			isStandalone: true,
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FlexOffsetDirective,
	decorators: [{ type: Directive }],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: i2.Directionality },
		{ type: FlexOffsetStyleBuilder },
		{ type: i1.MediaMarshaller },
		{ type: i1.StyleUtils }
	]
});
var DefaultFlexOffsetDirective = class DefaultFlexOffsetDirective extends FlexOffsetDirective {
	constructor() {
		super(...arguments);
		this.inputs = inputs$2;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: DefaultFlexOffsetDirective,
			deps: null,
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: DefaultFlexOffsetDirective,
			isStandalone: false,
			selector: "\n  [fxFlexOffset], [fxFlexOffset.xs], [fxFlexOffset.sm], [fxFlexOffset.md],\n  [fxFlexOffset.lg], [fxFlexOffset.xl], [fxFlexOffset.lt-sm], [fxFlexOffset.lt-md],\n  [fxFlexOffset.lt-lg], [fxFlexOffset.lt-xl], [fxFlexOffset.gt-xs], [fxFlexOffset.gt-sm],\n  [fxFlexOffset.gt-md], [fxFlexOffset.gt-lg]\n",
			inputs: {
				fxFlexOffset: "fxFlexOffset",
				"fxFlexOffset.xs": "fxFlexOffset.xs",
				"fxFlexOffset.sm": "fxFlexOffset.sm",
				"fxFlexOffset.md": "fxFlexOffset.md",
				"fxFlexOffset.lg": "fxFlexOffset.lg",
				"fxFlexOffset.xl": "fxFlexOffset.xl",
				"fxFlexOffset.lt-sm": "fxFlexOffset.lt-sm",
				"fxFlexOffset.lt-md": "fxFlexOffset.lt-md",
				"fxFlexOffset.lt-lg": "fxFlexOffset.lt-lg",
				"fxFlexOffset.lt-xl": "fxFlexOffset.lt-xl",
				"fxFlexOffset.gt-xs": "fxFlexOffset.gt-xs",
				"fxFlexOffset.gt-sm": "fxFlexOffset.gt-sm",
				"fxFlexOffset.gt-md": "fxFlexOffset.gt-md",
				"fxFlexOffset.gt-lg": "fxFlexOffset.gt-lg"
			},
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DefaultFlexOffsetDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: selector$2,
			inputs: inputs$2,
			standalone: false
		}]
	}]
});
const flexOffsetCacheRowRtl = /* @__PURE__ */ new Map();
const flexOffsetCacheColumnRtl = /* @__PURE__ */ new Map();
const flexOffsetCacheRowLtr = /* @__PURE__ */ new Map();
const flexOffsetCacheColumnLtr = /* @__PURE__ */ new Map();
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
var FlexAlignStyleBuilder = class FlexAlignStyleBuilder extends StyleBuilder {
	buildStyles(input) {
		input = input || "stretch";
		const styles = {};
		switch (input) {
			case "start":
				styles["align-self"] = "flex-start";
				break;
			case "end":
				styles["align-self"] = "flex-end";
				break;
			default: styles["align-self"] = input;
		}
		return styles;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: FlexAlignStyleBuilder,
			deps: null,
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: FlexAlignStyleBuilder,
			providedIn: "root"
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FlexAlignStyleBuilder,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
const inputs$1 = [
	"fxFlexAlign",
	"fxFlexAlign.xs",
	"fxFlexAlign.sm",
	"fxFlexAlign.md",
	"fxFlexAlign.lg",
	"fxFlexAlign.xl",
	"fxFlexAlign.lt-sm",
	"fxFlexAlign.lt-md",
	"fxFlexAlign.lt-lg",
	"fxFlexAlign.lt-xl",
	"fxFlexAlign.gt-xs",
	"fxFlexAlign.gt-sm",
	"fxFlexAlign.gt-md",
	"fxFlexAlign.gt-lg"
];
const selector$1 = `
  [fxFlexAlign], [fxFlexAlign.xs], [fxFlexAlign.sm], [fxFlexAlign.md],
  [fxFlexAlign.lg], [fxFlexAlign.xl], [fxFlexAlign.lt-sm], [fxFlexAlign.lt-md],
  [fxFlexAlign.lt-lg], [fxFlexAlign.lt-xl], [fxFlexAlign.gt-xs], [fxFlexAlign.gt-sm],
  [fxFlexAlign.gt-md], [fxFlexAlign.gt-lg]
`;
var FlexAlignDirective = class FlexAlignDirective extends BaseDirective2 {
	constructor(elRef, styleUtils, styleBuilder, marshal) {
		super(elRef, styleBuilder, styleUtils, marshal);
		this.DIRECTIVE_KEY = "flex-align";
		this.styleCache = flexAlignCache;
		this.init();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: FlexAlignDirective,
			deps: [
				{ token: i0.ElementRef },
				{ token: i1.StyleUtils },
				{ token: FlexAlignStyleBuilder },
				{ token: i1.MediaMarshaller }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: FlexAlignDirective,
			isStandalone: true,
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FlexAlignDirective,
	decorators: [{ type: Directive }],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: i1.StyleUtils },
		{ type: FlexAlignStyleBuilder },
		{ type: i1.MediaMarshaller }
	]
});
const flexAlignCache = /* @__PURE__ */ new Map();
var DefaultFlexAlignDirective = class DefaultFlexAlignDirective extends FlexAlignDirective {
	constructor() {
		super(...arguments);
		this.inputs = inputs$1;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: DefaultFlexAlignDirective,
			deps: null,
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: DefaultFlexAlignDirective,
			isStandalone: false,
			selector: "\n  [fxFlexAlign], [fxFlexAlign.xs], [fxFlexAlign.sm], [fxFlexAlign.md],\n  [fxFlexAlign.lg], [fxFlexAlign.xl], [fxFlexAlign.lt-sm], [fxFlexAlign.lt-md],\n  [fxFlexAlign.lt-lg], [fxFlexAlign.lt-xl], [fxFlexAlign.gt-xs], [fxFlexAlign.gt-sm],\n  [fxFlexAlign.gt-md], [fxFlexAlign.gt-lg]\n",
			inputs: {
				fxFlexAlign: "fxFlexAlign",
				"fxFlexAlign.xs": "fxFlexAlign.xs",
				"fxFlexAlign.sm": "fxFlexAlign.sm",
				"fxFlexAlign.md": "fxFlexAlign.md",
				"fxFlexAlign.lg": "fxFlexAlign.lg",
				"fxFlexAlign.xl": "fxFlexAlign.xl",
				"fxFlexAlign.lt-sm": "fxFlexAlign.lt-sm",
				"fxFlexAlign.lt-md": "fxFlexAlign.lt-md",
				"fxFlexAlign.lt-lg": "fxFlexAlign.lt-lg",
				"fxFlexAlign.lt-xl": "fxFlexAlign.lt-xl",
				"fxFlexAlign.gt-xs": "fxFlexAlign.gt-xs",
				"fxFlexAlign.gt-sm": "fxFlexAlign.gt-sm",
				"fxFlexAlign.gt-md": "fxFlexAlign.gt-md",
				"fxFlexAlign.gt-lg": "fxFlexAlign.gt-lg"
			},
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DefaultFlexAlignDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: selector$1,
			inputs: inputs$1,
			standalone: false
		}]
	}]
});
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
const FLEX_FILL_CSS = {
	"margin": 0,
	"width": "100%",
	"height": "100%",
	"min-width": "100%",
	"min-height": "100%"
};
var FlexFillStyleBuilder = class FlexFillStyleBuilder extends StyleBuilder {
	buildStyles(_input) {
		return FLEX_FILL_CSS;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: FlexFillStyleBuilder,
			deps: null,
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: FlexFillStyleBuilder,
			providedIn: "root"
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FlexFillStyleBuilder,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
var FlexFillDirective = class FlexFillDirective extends BaseDirective2 {
	constructor(elRef, styleUtils, styleBuilder, marshal) {
		super(elRef, styleBuilder, styleUtils, marshal);
		this.styleCache = flexFillCache;
		this.addStyles("");
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: FlexFillDirective,
			deps: [
				{ token: i0.ElementRef },
				{ token: i1.StyleUtils },
				{ token: FlexFillStyleBuilder },
				{ token: i1.MediaMarshaller }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: FlexFillDirective,
			isStandalone: false,
			selector: "[fxFill], [fxFlexFill]",
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FlexFillDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: `[fxFill], [fxFlexFill]`,
			standalone: false
		}]
	}],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: i1.StyleUtils },
		{ type: FlexFillStyleBuilder },
		{ type: i1.MediaMarshaller }
	]
});
const flexFillCache = /* @__PURE__ */ new Map();
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
var LayoutAlignStyleBuilder = class LayoutAlignStyleBuilder extends StyleBuilder {
	buildStyles(align, parent) {
		const css = {}, [mainAxis, crossAxis] = align.split(" ");
		switch (mainAxis) {
			case "center":
				css["justify-content"] = "center";
				break;
			case "space-around":
				css["justify-content"] = "space-around";
				break;
			case "space-between":
				css["justify-content"] = "space-between";
				break;
			case "space-evenly":
				css["justify-content"] = "space-evenly";
				break;
			case "end":
			case "flex-end":
				css["justify-content"] = "flex-end";
				break;
			default: css["justify-content"] = "flex-start";
		}
		switch (crossAxis) {
			case "start":
			case "flex-start":
				css["align-items"] = css["align-content"] = "flex-start";
				break;
			case "center":
				css["align-items"] = css["align-content"] = "center";
				break;
			case "end":
			case "flex-end":
				css["align-items"] = css["align-content"] = "flex-end";
				break;
			case "space-between":
				css["align-content"] = "space-between";
				css["align-items"] = "stretch";
				break;
			case "space-around":
				css["align-content"] = "space-around";
				css["align-items"] = "stretch";
				break;
			case "baseline":
				css["align-content"] = "stretch";
				css["align-items"] = "baseline";
				break;
			default: css["align-items"] = css["align-content"] = "stretch";
		}
		return extendObject(css, {
			"display": parent.inline ? "inline-flex" : "flex",
			"flex-direction": parent.layout,
			"box-sizing": "border-box",
			"max-width": crossAxis === "stretch" ? !isFlowHorizontal(parent.layout) ? "100%" : null : null,
			"max-height": crossAxis === "stretch" ? isFlowHorizontal(parent.layout) ? "100%" : null : null
		});
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: LayoutAlignStyleBuilder,
			deps: null,
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: LayoutAlignStyleBuilder,
			providedIn: "root"
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: LayoutAlignStyleBuilder,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
const inputs = [
	"fxLayoutAlign",
	"fxLayoutAlign.xs",
	"fxLayoutAlign.sm",
	"fxLayoutAlign.md",
	"fxLayoutAlign.lg",
	"fxLayoutAlign.xl",
	"fxLayoutAlign.lt-sm",
	"fxLayoutAlign.lt-md",
	"fxLayoutAlign.lt-lg",
	"fxLayoutAlign.lt-xl",
	"fxLayoutAlign.gt-xs",
	"fxLayoutAlign.gt-sm",
	"fxLayoutAlign.gt-md",
	"fxLayoutAlign.gt-lg"
];
const selector = `
  [fxLayoutAlign], [fxLayoutAlign.xs], [fxLayoutAlign.sm], [fxLayoutAlign.md],
  [fxLayoutAlign.lg], [fxLayoutAlign.xl], [fxLayoutAlign.lt-sm], [fxLayoutAlign.lt-md],
  [fxLayoutAlign.lt-lg], [fxLayoutAlign.lt-xl], [fxLayoutAlign.gt-xs], [fxLayoutAlign.gt-sm],
  [fxLayoutAlign.gt-md], [fxLayoutAlign.gt-lg]
`;
var LayoutAlignDirective = class LayoutAlignDirective extends BaseDirective2 {
	constructor(elRef, styleUtils, styleBuilder, marshal) {
		super(elRef, styleBuilder, styleUtils, marshal);
		this.DIRECTIVE_KEY = "layout-align";
		this.layout = "row";
		this.inline = false;
		this.init();
		this.marshal.trackValue(this.nativeElement, "layout").pipe(takeUntil(this.destroySubject)).subscribe(this.onLayoutChange.bind(this));
	}
	updateWithValue(value) {
		const layout = this.layout || "row";
		const inline = this.inline;
		if (layout === "row" && inline) this.styleCache = layoutAlignHorizontalInlineCache;
		else if (layout === "row" && !inline) this.styleCache = layoutAlignHorizontalCache;
		else if (layout === "row-reverse" && inline) this.styleCache = layoutAlignHorizontalRevInlineCache;
		else if (layout === "row-reverse" && !inline) this.styleCache = layoutAlignHorizontalRevCache;
		else if (layout === "column" && inline) this.styleCache = layoutAlignVerticalInlineCache;
		else if (layout === "column" && !inline) this.styleCache = layoutAlignVerticalCache;
		else if (layout === "column-reverse" && inline) this.styleCache = layoutAlignVerticalRevInlineCache;
		else if (layout === "column-reverse" && !inline) this.styleCache = layoutAlignVerticalRevCache;
		this.addStyles(value, {
			layout,
			inline
		});
	}
	onLayoutChange(matcher) {
		const layoutKeys = matcher.value.split(" ");
		this.layout = layoutKeys[0];
		this.inline = matcher.value.includes("inline");
		if (!LAYOUT_VALUES.find((x) => x === this.layout)) this.layout = "row";
		this.triggerUpdate();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: LayoutAlignDirective,
			deps: [
				{ token: i0.ElementRef },
				{ token: i1.StyleUtils },
				{ token: LayoutAlignStyleBuilder },
				{ token: i1.MediaMarshaller }
			],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: LayoutAlignDirective,
			isStandalone: true,
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: LayoutAlignDirective,
	decorators: [{ type: Directive }],
	ctorParameters: () => [
		{ type: i0.ElementRef },
		{ type: i1.StyleUtils },
		{ type: LayoutAlignStyleBuilder },
		{ type: i1.MediaMarshaller }
	]
});
var DefaultLayoutAlignDirective = class DefaultLayoutAlignDirective extends LayoutAlignDirective {
	constructor() {
		super(...arguments);
		this.inputs = inputs;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: DefaultLayoutAlignDirective,
			deps: null,
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: DefaultLayoutAlignDirective,
			isStandalone: false,
			selector: "\n  [fxLayoutAlign], [fxLayoutAlign.xs], [fxLayoutAlign.sm], [fxLayoutAlign.md],\n  [fxLayoutAlign.lg], [fxLayoutAlign.xl], [fxLayoutAlign.lt-sm], [fxLayoutAlign.lt-md],\n  [fxLayoutAlign.lt-lg], [fxLayoutAlign.lt-xl], [fxLayoutAlign.gt-xs], [fxLayoutAlign.gt-sm],\n  [fxLayoutAlign.gt-md], [fxLayoutAlign.gt-lg]\n",
			inputs: {
				fxLayoutAlign: "fxLayoutAlign",
				"fxLayoutAlign.xs": "fxLayoutAlign.xs",
				"fxLayoutAlign.sm": "fxLayoutAlign.sm",
				"fxLayoutAlign.md": "fxLayoutAlign.md",
				"fxLayoutAlign.lg": "fxLayoutAlign.lg",
				"fxLayoutAlign.xl": "fxLayoutAlign.xl",
				"fxLayoutAlign.lt-sm": "fxLayoutAlign.lt-sm",
				"fxLayoutAlign.lt-md": "fxLayoutAlign.lt-md",
				"fxLayoutAlign.lt-lg": "fxLayoutAlign.lt-lg",
				"fxLayoutAlign.lt-xl": "fxLayoutAlign.lt-xl",
				"fxLayoutAlign.gt-xs": "fxLayoutAlign.gt-xs",
				"fxLayoutAlign.gt-sm": "fxLayoutAlign.gt-sm",
				"fxLayoutAlign.gt-md": "fxLayoutAlign.gt-md",
				"fxLayoutAlign.gt-lg": "fxLayoutAlign.gt-lg"
			},
			usesInheritance: true,
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DefaultLayoutAlignDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector,
			inputs,
			standalone: false
		}]
	}]
});
const layoutAlignHorizontalCache = /* @__PURE__ */ new Map();
const layoutAlignVerticalCache = /* @__PURE__ */ new Map();
const layoutAlignHorizontalRevCache = /* @__PURE__ */ new Map();
const layoutAlignVerticalRevCache = /* @__PURE__ */ new Map();
const layoutAlignHorizontalInlineCache = /* @__PURE__ */ new Map();
const layoutAlignVerticalInlineCache = /* @__PURE__ */ new Map();
const layoutAlignHorizontalRevInlineCache = /* @__PURE__ */ new Map();
const layoutAlignVerticalRevInlineCache = /* @__PURE__ */ new Map();
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
const ALL_DIRECTIVES = [
	DefaultLayoutDirective,
	DefaultLayoutGapDirective,
	DefaultLayoutAlignDirective,
	DefaultFlexOrderDirective,
	DefaultFlexOffsetDirective,
	FlexFillDirective,
	DefaultFlexAlignDirective,
	DefaultFlexDirective
];
var FlexModule = class FlexModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: FlexModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: FlexModule,
			declarations: [
				DefaultLayoutDirective,
				DefaultLayoutGapDirective,
				DefaultLayoutAlignDirective,
				DefaultFlexOrderDirective,
				DefaultFlexOffsetDirective,
				FlexFillDirective,
				DefaultFlexAlignDirective,
				DefaultFlexDirective
			],
			imports: [CoreModule, BidiModule],
			exports: [
				DefaultLayoutDirective,
				DefaultLayoutGapDirective,
				DefaultLayoutAlignDirective,
				DefaultFlexOrderDirective,
				DefaultFlexOffsetDirective,
				FlexFillDirective,
				DefaultFlexAlignDirective,
				DefaultFlexDirective
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: FlexModule,
			imports: [CoreModule, BidiModule]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FlexModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [CoreModule, BidiModule],
			declarations: [...ALL_DIRECTIVES],
			exports: [...ALL_DIRECTIVES]
		}]
	}]
});
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
export { DefaultFlexAlignDirective, DefaultFlexDirective, DefaultFlexOffsetDirective, DefaultFlexOrderDirective, DefaultLayoutAlignDirective, DefaultLayoutDirective, DefaultLayoutGapDirective, FlexAlignDirective, FlexAlignStyleBuilder, FlexDirective, FlexFillDirective, FlexFillStyleBuilder, FlexModule, FlexOffsetDirective, FlexOffsetStyleBuilder, FlexOrderDirective, FlexOrderStyleBuilder, FlexStyleBuilder, LayoutAlignDirective, LayoutAlignStyleBuilder, LayoutDirective, LayoutGapDirective, LayoutGapStyleBuilder, LayoutStyleBuilder };

//# sourceMappingURL=angular-flex-layout-flex.mjs.map