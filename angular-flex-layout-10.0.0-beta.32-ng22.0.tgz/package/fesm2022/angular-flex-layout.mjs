import * as i0 from "@angular/core";
import { Inject, NgModule, PLATFORM_ID, Version } from "@angular/core";
import { BREAKPOINT, DEFAULT_CONFIG, LAYOUT_CONFIG, SERVER_TOKEN } from "@angular/flex-layout/core";
import { ExtendedModule } from "@angular/flex-layout/extended";
import { FlexModule } from "@angular/flex-layout/flex";
import { GridModule } from "@angular/flex-layout/grid";
import { isPlatformServer } from "@angular/common";
export * from "@angular/flex-layout/core";
export * from "@angular/flex-layout/extended";
export * from "@angular/flex-layout/flex";
export * from "@angular/flex-layout/grid";
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
const VERSION = new Version("10.0.0-beta.32-ng22.0");
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
var FlexLayoutModule = class FlexLayoutModule {
	static withConfig(configOptions, breakpoints = []) {
		return {
			ngModule: FlexLayoutModule,
			providers: configOptions.serverLoaded ? [
				{
					provide: LAYOUT_CONFIG,
					useValue: {
						...DEFAULT_CONFIG,
						...configOptions
					}
				},
				{
					provide: BREAKPOINT,
					useValue: breakpoints,
					multi: true
				},
				{
					provide: SERVER_TOKEN,
					useValue: true
				}
			] : [{
				provide: LAYOUT_CONFIG,
				useValue: {
					...DEFAULT_CONFIG,
					...configOptions
				}
			}, {
				provide: BREAKPOINT,
				useValue: breakpoints,
				multi: true
			}]
		};
	}
	constructor(serverModuleLoaded, platformId) {
		if (isPlatformServer(platformId) && !serverModuleLoaded) console.warn("Warning: Flex Layout loaded on the server without FlexLayoutServerModule");
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: FlexLayoutModule,
			deps: [{ token: SERVER_TOKEN }, { token: PLATFORM_ID }],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: FlexLayoutModule,
			imports: [
				FlexModule,
				ExtendedModule,
				GridModule
			],
			exports: [
				FlexModule,
				ExtendedModule,
				GridModule
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: FlexLayoutModule,
			imports: [
				FlexModule,
				ExtendedModule,
				GridModule,
				FlexModule,
				ExtendedModule,
				GridModule
			]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FlexLayoutModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [
				FlexModule,
				ExtendedModule,
				GridModule
			],
			exports: [
				FlexModule,
				ExtendedModule,
				GridModule
			]
		}]
	}],
	ctorParameters: () => [{
		type: void 0,
		decorators: [{
			type: Inject,
			args: [SERVER_TOKEN]
		}]
	}, {
		type: Object,
		decorators: [{
			type: Inject,
			args: [PLATFORM_ID]
		}]
	}]
});
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.io/license
*/
export { FlexLayoutModule, VERSION };

//# sourceMappingURL=angular-flex-layout.mjs.map